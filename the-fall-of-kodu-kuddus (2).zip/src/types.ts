export interface Complaint {
  id: string;
  category: string;
  description: string;
  rollNumber: string;
  timestamp: string;
  status: 'Received' | 'Investigating' | 'Archived';
}

export interface Student {
  id: string;
  name: string;
  roll: string;
  height: number; // in cm
}

export interface Seat {
  student: Student | null;
  row: number;
  col: number;
  isBlocked?: boolean;
  blockedBy?: string; // name of the student blocking them
}

export interface LedgerLog {
  id: string;
  type: 'toll' | 'tiffin';
  description: string;
  amount: number; // in Taka or Caloric equivalent
  victim: string;
  perpetrator: string;
  timestamp: string;
}

export interface SOSAlert {
  id: string;
  location: string;
  message: string;
  timestamp: string;
  reporter: string;
  status: 'ACTIVE' | 'RESOLVED';
  isSynced: boolean;
}

export interface FactRule {
  id: string;
  keywords: string[];
  claimPattern: string;
  verdict: 'TRUE' | 'FALSE' | 'EXAGGERATED' | 'MYTH';
  confidence: number;
  explanation: string;
  ruleQuote: string;
}
