import { Student, Seat, FactRule } from './types';
import { FACT_RULES } from './constants';

/**
 * Evaluates a classroom grid and detects if any student's line of sight
 * is blocked by a taller student sitting directly in front of them in the same column.
 */
export function evaluateLineOfSight(grid: Seat[][]): Seat[][] {
  const evaluated = grid.map(row => row.map(cell => ({ ...cell, isBlocked: false, blockedBy: undefined })));
  
  // Start from row 1 (the second row) and look at the student directly in front (row - 1)
  for (let r = 1; r < evaluated.length; r++) {
    for (let c = 0; c < evaluated[r].length; c++) {
      const currentCell = evaluated[r][c];
      if (currentCell.student) {
        // Look at all students directly in front in this column
        for (let prevR = 0; prevR < r; prevR++) {
          const frontCell = evaluated[prevR][c];
          if (frontCell.student && frontCell.student.height >= currentCell.student.height) {
            currentCell.isBlocked = true;
            currentCell.blockedBy = frontCell.student.name;
            break; // Already blocked
          }
        }
      }
    }
  }
  return evaluated;
}

/**
 * Sorts students by height in ascending order and places them into an NxM grid
 * from front (Row 0) to back (Row N-1), minimizing line-of-sight blocks.
 */
export function optimizeSeating(students: Student[], rows: number, cols: number): Seat[][] {
  // Create empty grid
  const grid: Seat[][] = Array.from({ length: rows }, (_, r) =>
    Array.from({ length: cols }, (_, c) => ({
      student: null,
      row: r,
      col: c,
    }))
  );

  // Filter out any empty students and sort by height ascending (shortest first)
  const sortedStudents = [...students].sort((a, b) => a.height - b.height);

  let studentIdx = 0;
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      if (studentIdx < sortedStudents.length) {
        grid[r][c].student = sortedStudents[studentIdx];
        studentIdx++;
      }
    }
  }

  // Evaluate the newly arranged grid
  return evaluateLineOfSight(grid);
}

/**
 * Calculates Caloric Loss vs Kinetic Disparity metrics.
 * 1 kcal = 4.184 kJ
 * Splitting kinetic energy vs work needed to escape.
 */
export interface CaloricResult {
  calories: number;
  runDistanceKm: number; // escape distance
  pushupsNeeded: number;
  samosaEquiv: number;
  singaraEquiv: number;
  tiffinCredits: number;
}

export function calculateCaloricDisparity(description: string, amountTaka: number): CaloricResult {
  // Guess calories based on description keywords
  let calories = Math.round(amountTaka * 2.5); // base conversion: 1 Taka ~ 2.5 calories
  const descLower = description.toLowerCase();
  
  if (descLower.includes('samosa') || descLower.includes('shingara') || descLower.includes('singara')) {
    calories += 250;
  } else if (descLower.includes('burger') || descLower.includes('sandwich')) {
    calories += 450;
  } else if (descLower.includes('kabab') || descLower.includes('meat')) {
    calories += 350;
  } else if (descLower.includes('chocolate') || descLower.includes('sweet')) {
    calories += 200;
  } else if (descLower.includes('toll') || descLower.includes('bypass')) {
    calories = Math.round(amountTaka * 1.2); // tolls consume less "physical tiffin food" but high stress!
  }

  // running burn rate is roughly 65 kcal per km for a student
  const runDistanceKm = parseFloat((calories / 65).toFixed(2));
  // average pushup burns 0.5 calories
  const pushupsNeeded = Math.round(calories / 0.5);
  
  // Currency equivalencies
  const samosaPrice = 15;
  const singaraPrice = 12;
  const samosaEquiv = parseFloat((amountTaka / samosaPrice).toFixed(1));
  const singaraEquiv = parseFloat((amountTaka / singaraPrice).toFixed(1));
  const tiffinCredits = Math.round(amountTaka * 1.5);

  return {
    calories,
    runDistanceKm,
    pushupsNeeded,
    samosaEquiv,
    singaraEquiv,
    tiffinCredits,
  };
}

/**
 * Fact-checker query matching.
 * Matches keywords to pre-seeded rules.
 * If no match, generates a funny simulated response.
 */
export interface FactCheckResult {
  statement: string;
  verdict: 'TRUE' | 'FALSE' | 'EXAGGERATED' | 'MYTH';
  confidence: number;
  explanation: string;
  ruleQuote: string;
  isSimulated: boolean;
}

export function performFactCheck(query: string): FactCheckResult {
  const queryLower = query.toLowerCase();
  
  if (!query.trim()) {
    return {
      statement: "No claim entered.",
      verdict: 'FALSE',
      confidence: 0,
      explanation: "Please enter a claim spoken by Kodu Kuddus to activate the fact-checker scanner.",
      ruleQuote: "System Manual Section 0",
      isSimulated: false
    };
  }

  // Try to find a match in pre-seeded rules
  let bestRule: FactRule | null = null;
  let maxMatches = 0;

  for (const rule of FACT_RULES) {
    let matches = 0;
    for (const kw of rule.keywords) {
      if (queryLower.includes(kw)) {
        matches++;
      }
    }
    // Boost matches if the general claim matches
    if (queryLower.includes(rule.claimPattern.toLowerCase().substring(0, 15))) {
      matches += 2;
    }

    if (matches > maxMatches && matches > 0) {
      maxMatches = matches;
      bestRule = rule;
    }
  }

  if (bestRule) {
    return {
      statement: bestRule.claimPattern,
      verdict: bestRule.verdict,
      confidence: bestRule.confidence,
      explanation: bestRule.explanation,
      ruleQuote: bestRule.ruleQuote,
      isSimulated: false
    };
  }

  // Semantic simulation fallback for unseeded queries
  const dynamicVerdicts: Array<'TRUE' | 'FALSE' | 'EXAGGERATED' | 'MYTH'> = ['FALSE', 'MYTH', 'EXAGGERATED'];
  const chosenVerdict = dynamicVerdicts[Math.floor((query.length * 7) % dynamicVerdicts.length)];
  const confidence = Math.round(70 + ((query.length * 3) % 29)); // Dynamic confidence between 70% and 99%
  
  let explanation = "";
  let quote = "";

  if (chosenVerdict === 'FALSE') {
    explanation = `The resistance database has scanned this claim ("${query}"). This statement is flat-out false. Kuddus attempted to back this up with a printed spreadsheet, but close inspection of the paper metadata revealed it was designed in Microsoft Paint by his cousin.`;
    quote = `Resistance Scan Digest #${Math.round(100 + (query.length % 900))}: "Aesthetic fonts cannot cover up corrupted variables."`;
  } else if (chosenVerdict === 'MYTH') {
    explanation = `This claim is a legendary classroom fabrication designed to instill academic terror. Student council records dating back five cohorts confirm this was originally a joke started by a backbencher that Kuddus eventually adopted as historical fact.`;
    quote = `Rebel Whispers Vol 3: "And thus, Kodu became the hero of stories that never happened."`;
  } else {
    explanation = `This claim contains exactly 2% truth wrapped in 98% dramatic fluff. While Kuddus indeed accomplished a fraction of this, he has magnified the statistics to cosmic levels to justify his endless quiz assignments.`;
    quote = `Dramatization Audit Report: "Syllabus inflated by 400% for aesthetic intimidation."`;
  }

  return {
    statement: `Kuddus claims: "${query}"`,
    verdict: chosenVerdict,
    confidence,
    explanation,
    ruleQuote: quote,
    isSimulated: true
  };
}
