import { Student, Complaint, LedgerLog, FactRule } from './types';

export const INITIAL_STUDENTS: Student[] = [
  { id: 's1', name: 'Zayan Kabir', roll: '210101', height: 162 },
  { id: 's2', name: 'Nafis Ahmed', roll: '210102', height: 185 },
  { id: 's3', name: 'Sanjida Sultana', roll: '210103', height: 154 },
  { id: 's4', name: 'Tanveer Hasan', roll: '210104', height: 178 },
  { id: 's5', name: 'Afsana Mimi', roll: '210105', height: 158 },
  { id: 's6', name: 'Maimuna Islam', roll: '210106', height: 161 },
  { id: 's7', name: 'Adnan Sami', roll: '210107', height: 172 },
  { id: 's8', name: 'Rifat Chowdhury', roll: '210108', height: 180 },
  { id: 's9', name: 'Farhan Aqib', roll: '210109', height: 167 },
  { id: 's10', name: 'Tasnim Zara', roll: '210110', height: 155 },
  { id: 's11', name: 'Sadia Rahman', roll: '210111', height: 160 },
  { id: 's12', name: 'Wasif Zaman', roll: '210112', height: 175 },
];

export const INITIAL_COMPLAINTS: Complaint[] = [
  {
    id: 'c1',
    category: 'Homework Overload',
    description: 'Assigned a 40-page math sheet on the eve of Eid vacation because "rebellion breeds in idle minds".',
    rollNumber: '210103',
    timestamp: '2026-07-11 14:30',
    status: 'Investigating',
  },
  {
    id: 'c2',
    category: 'Unfair Seating',
    description: 'Placed 6-foot tall Nafis in the first row directly in front of 5-foot Tasnim, making Tasnim a permanent ghost in class.',
    rollNumber: '210110',
    timestamp: '2026-07-11 11:15',
    status: 'Received',
  },
  {
    id: 'c3',
    category: 'Tiffin Confiscation',
    description: 'Confiscated homemade Beef Samosas under the pretext of "contraband high-cholesterol distractions". Later seen eating them in the staff room.',
    rollNumber: '210101',
    timestamp: '2026-07-10 13:05',
    status: 'Archived',
  },
];

export const INITIAL_LEDGER_LOGS: LedgerLog[] = [
  {
    id: 'l1',
    type: 'toll',
    description: 'Emergency corridor permit tax',
    amount: 15,
    victim: 'Zayan Kabir',
    perpetrator: 'Class Captain (Kuddus Loyalist)',
    timestamp: '2026-07-12 09:10',
  },
  {
    id: 'l2',
    type: 'tiffin',
    description: 'Nutella Sandwich robbery at Desk 4',
    amount: 120, // Value in Taka
    victim: 'Sadia Rahman',
    perpetrator: 'Head Monitor',
    timestamp: '2026-07-11 12:45',
  },
  {
    id: 'l3',
    type: 'toll',
    description: 'Bathroom entry fee: Emergency bypass',
    amount: 30,
    victim: 'Farhan Aqib',
    perpetrator: 'Hall Monitor Guild',
    timestamp: '2026-07-11 10:00',
  },
  {
    id: 'l4',
    type: 'tiffin',
    description: 'Shami Kabab and Paratha pillage',
    amount: 150,
    victim: 'Sanjida Sultana',
    perpetrator: 'Kuddus Patrol Team',
    timestamp: '2026-07-10 13:20',
  },
];

export const FACT_RULES: FactRule[] = [
  {
    id: 'f1',
    keywords: ['gold', 'medalist', 'medal', 'first', 'university'],
    claimPattern: 'Kuddus claims he won the Gold Medal in his university.',
    verdict: 'FALSE',
    confidence: 99,
    explanation: 'Archival records from the University of Gourd Studies reveal Kuddus was actually disqualified for smuggling crib sheets inside a hollowed-out pumpkin (Kodu).',
    ruleQuote: 'Rebel Ledger Section 4.2: "The Great Pumpkin Caper of \'98"'
  },
  {
    id: 'f2',
    keywords: ['harvard', 'phd', 'doctorate', 'degree', 'cambridge'],
    claimPattern: 'Kuddus claims he holds a PhD from Harvard.',
    verdict: 'MYTH',
    confidence: 95,
    explanation: 'Kuddus never went to Boston. He took a 2-hour online seminar titled "Harvard Style Referencing for Beginners" and printed his own certificate on fluorescent green cardstock.',
    ruleQuote: 'Student Council Intel Report: "Fluorescent paper receipts found in Kuddus\'s drawer."'
  },
  {
    id: 'f3',
    keywords: ['walk', 'miles', 'km', 'mountain', 'uphill', 'school', 'river'],
    claimPattern: 'Kuddus claims he walked 20 kilometers to school, crossing three rivers and hiking two mountains.',
    verdict: 'EXAGGERATED',
    confidence: 88,
    explanation: 'Google Maps coordinates of his childhood village indicate his house was 450 meters away from the primary school. The "rivers" were shallow irrigation drains, and the "mountains" were compost mounds.',
    ruleQuote: 'Terrain Analysis 2026: "Elevation gain was exactly 1.2 meters."'
  },
  {
    id: 'f4',
    keywords: ['sleep', 'never', '24 hours', 'study', 'awake'],
    claimPattern: 'Kuddus claims he studied 24 hours a day and never sleeps.',
    verdict: 'FALSE',
    confidence: 92,
    explanation: 'Multiple students have photographed Kuddus snoring loudly behind a propped-up upright textbook during English Literature, occasionally muttering about "stolen samosas".',
    ruleQuote: 'Audio Recording Rebel-Drive: "Kuddus_Snore_Remix_128kbps.mp3"'
  },
  {
    id: 'f5',
    keywords: ['mind', 'read', 'telepathy', 'thought', 'exam'],
    claimPattern: 'Kuddus claims he can read students\' minds during exams.',
    verdict: 'FALSE',
    confidence: 97,
    explanation: 'He does not read minds; he has a highly reflective panoramic mirror installed on the back wall of the classroom and wears double-focal reading glasses to catch whispering desk reflection angles.',
    ruleQuote: 'Hardware Audit: "Classroom mirror angles calculated at 42.5 degrees for maximum surveillance."'
  },
  {
    id: 'f6',
    keywords: ['textbook', 'mistake', 'corrected', 'author', 'smart'],
    claimPattern: 'Kuddus claims he corrected the errors of the textbook authors.',
    verdict: 'EXAGGERATED',
    confidence: 75,
    explanation: 'He did find a typo on Page 44 where "integration" was spelled "integretion", which he spent a 50-minute lecture celebrating as his own mathematical triumph.',
    ruleQuote: 'Lecture Notes Archive: "Page 44 red pen circle occupies 85% of the page margin."'
  },
];

export const DICTATORSHIP_NARRATIVE = {
  title: "The Reign of the Bitter Melon (Kodu)",
  subtitle: "Inside the Academical Tyranny of Kodu Kuddus",
  paragraphs: [
    "It began in the spring of '24. Under the iron fist of Kodu Kuddus, our classroom was converted from a sanctuary of learning into a high-security penal colony. The beloved morning tiffin break was outlawed under Decree 12, classified as 'an unauthorized gathering of caloric conspirators'. Home-cooked parathas, samosas, and chocolate milk are now systematically pillaged by loyalist monitors, only to mysteriously reappear as fuel in the staff room lounge.",
    "But the tyranny doesn't end in the lunchbox. Kuddus instituted the infamous 'Camouflage Seating Order', placing the tallest athletes in the front row and shorter students behind them, effectively creating a physical firewall of human flesh to block line-of-sight. The corridor is guarded by washroom toll booths where students must pay custom taxes (measured in Samosa-units or physical Taka) just to empty their bladders.",
    "We, the rebel students of Class XII-B, have finally broken our silence. We have built this top-secret digital hub—the Rebel Resistance Headquarters—hidden under the nose of Kuddus's server network. Here, we coordinate our campaigns, optimize our seating arrangements, log corrupt tolls, negotiate the endless syllabus, and expose the massive myths surrounding his academic accomplishments. Join the rebellion. The Fall of Kodu Kuddus begins now!"
  ]
};
