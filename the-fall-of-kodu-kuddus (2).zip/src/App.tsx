import React, { useState } from 'react';
import Navbar from './components/Navbar';
import Home from './components/Home';
import Dashboard from './components/Dashboard';
import Mission1Complaint from './components/Mission1Complaint';
import Mission2SeatPlanner from './components/Mission2SeatPlanner';
import Mission3Syllabus from './components/Mission3Syllabus';
import Mission4Ledger from './components/Mission4Ledger';
import Mission5SOS from './components/Mission5SOS';
import Mission6FactChecker from './components/Mission6FactChecker';

import { Student, Complaint, LedgerLog, SOSAlert } from './types';
import { INITIAL_STUDENTS, INITIAL_COMPLAINTS, INITIAL_LEDGER_LOGS } from './constants';
import { 
  ShieldCheck, 
  Compass, 
  LayoutGrid, 
  BookOpen, 
  Landmark, 
  ShieldAlert, 
  BadgeHelp, 
  ChevronLeft, 
  Sparkles, 
  Zap, 
  Star, 
  Terminal, 
  Volume2, 
  MessageSquare,
  AlertOctagon,
  X
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const [currentTab, setCurrentTab] = useState<string>('home');
  const [students, setStudents] = useState<Student[]>(INITIAL_STUDENTS);
  const [complaints, setComplaints] = useState<Complaint[]>(INITIAL_COMPLAINTS);
  const [logs, setLogs] = useState<LedgerLog[]>(INITIAL_LEDGER_LOGS);
  const [alerts, setAlerts] = useState<SOSAlert[]>([
    {
      id: 'sos_0101',
      location: 'Canteen',
      message: 'Kuddus patrol spotted inspecting lockers for hidden tiffin boxes!',
      timestamp: '09:42 AM',
      reporter: 'Agent Nishat',
      status: 'ACTIVE',
      isSynced: true,
    }
  ]);
  const [warningsCount, setWarningsCount] = useState<number>(2); // Start at 2/3 for classroom tension!
  const [isWidgetOpen, setIsWidgetOpen] = useState<boolean>(false);
  const [activeMemoIndex, setActiveMemoIndex] = useState<number>(0);

  // Bangladesh Backbench resistance secret memos
  const backbenchMemos = [
    "📌 MSG #32: Kuddus is holding a red grading pen. Hide all drafts immediately!",
    "📌 MSG #33: Canteen manager reports singaras are half-price if you mention 'Kodu Kuddus'.",
    "📌 MSG #34: Nafis managed to duplicate the syllabus answer key. Share quietly in row 4.",
    "📌 MSG #35: Target sighted near Section B. He is looking for tiffin extortion candidates.",
    "📌 MSG #36: Emergency escape route behind the green blackboard is clear of patrols."
  ];

  // Web Audio API Synthesizer beep
  const playBeep = (freq: number, type: OscillatorType, duration: number) => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gainNode = ctx.createGain();
      
      osc.type = type;
      osc.frequency.value = freq;
      
      gainNode.gain.setValueAtTime(0.15, ctx.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + duration);
      
      osc.connect(gainNode);
      gainNode.connect(ctx.destination);
      
      osc.start();
      osc.stop(ctx.currentTime + duration);
    } catch (e) {
      console.log("Audio not supported or interaction required first", e);
    }
  };

  const addComplaint = (newC: Complaint) => {
    setComplaints([newC, ...complaints]);
  };

  const addLog = (newL: LedgerLog) => {
    setLogs([newL, ...logs]);
  };

  const removeLog = (id: string) => {
    setLogs(logs.filter(l => l.id !== id));
  };

  const addAlert = (newA: SOSAlert) => {
    setAlerts([newA, ...alerts]);
  };

  const resolveAlert = (id: string) => {
    setAlerts(alerts.map(a => a.id === id ? { ...a, status: 'RESOLVED' as const } : a));
  };

  const clearAlerts = () => {
    setAlerts([]);
  };

  const incrementWarnings = () => {
    setWarningsCount(prev => Math.min(3, prev + 1));
  };

  const resetWarnings = () => {
    setWarningsCount(0);
  };

  // Page level animation variants
  const pageVariants = {
    initial: { opacity: 0, y: 15, scale: 0.99 },
    animate: { opacity: 1, y: 0, scale: 1 },
    exit: { opacity: 0, y: -15 },
    transition: { type: 'spring', stiffness: 120, damping: 14 }
  };

  // Render view depending on state
  const renderContent = () => {
    let content;
    switch (currentTab) {
      case 'home':
        content = <Home setCurrentTab={setCurrentTab} />;
        break;
      
      case 'missions':
        content = renderMissionsIndex();
        break;
      
      case 'dashboard':
        content = (
          <Dashboard
            complaints={complaints}
            students={students}
            logs={logs}
            alerts={alerts}
            warningsCount={warningsCount}
            setCurrentTab={setCurrentTab}
          />
        );
        break;
      
      case 'sos':
      case 'mission5':
        content = (
          <div className="space-y-4">
            {renderBackBtn()}
            <Mission5SOS
              alerts={alerts}
              addAlert={addAlert}
              resolveAlert={resolveAlert}
              clearAlerts={clearAlerts}
            />
          </div>
        );
        break;

      case 'mission1':
        content = (
          <div className="space-y-4">
            {renderBackBtn()}
            <Mission1Complaint
              complaints={complaints}
              addComplaint={addComplaint}
              warningsCount={warningsCount}
              incrementWarnings={incrementWarnings}
              resetWarnings={resetWarnings}
            />
          </div>
        );
        break;

      case 'mission2':
        content = (
          <div className="space-y-4">
            {renderBackBtn()}
            <Mission2SeatPlanner
              students={students}
              setStudents={setStudents}
            />
          </div>
        );
        break;

      case 'mission3':
        content = (
          <div className="space-y-4">
            {renderBackBtn()}
            <Mission3Syllabus />
          </div>
        );
        break;

      case 'mission4':
        content = (
          <div className="space-y-4">
            {renderBackBtn()}
            <Mission4Ledger
              logs={logs}
              addLog={addLog}
              removeLog={removeLog}
            />
          </div>
        );
        break;

      case 'mission6':
        content = (
          <div className="space-y-4">
            {renderBackBtn()}
            <Mission6FactChecker />
          </div>
        );
        break;

      default:
        content = <Home setCurrentTab={setCurrentTab} />;
    }

    return (
      <motion.div
        key={currentTab}
        initial="initial"
        animate="animate"
        exit="exit"
        variants={pageVariants}
        className="w-full"
      >
        {content}
      </motion.div>
    );
  };

  const renderBackBtn = () => (
    <motion.button
      whileHover={{ scale: 1.05, x: -3 }}
      whileTap={{ scale: 0.95 }}
      onClick={() => {
        playBeep(440, 'sine', 0.1);
        setCurrentTab('missions');
      }}
      className="inline-flex items-center gap-1.5 text-sm font-display font-black text-black bg-white hover:bg-zinc-50 border-4 border-black rounded-xl px-4 py-2.5 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:translate-x-[1px] hover:translate-y-[1px] cursor-pointer uppercase tracking-wider"
    >
      <ChevronLeft className="w-4 h-4 text-[#8B5CF6] stroke-[3]" />
      <span>Back to Missions</span>
    </motion.button>
  );

  const renderMissionsIndex = () => {
    const list = [
      { id: 'mission1', title: 'Mission 1: Complaint Portal', icon: ShieldCheck, color: 'bg-[#4D96FF] text-white', desc: 'Secure Roll-Auth submission box and mass classroom countdown tracker.' },
      { id: 'mission2', title: 'Mission 2: Seat Planner', icon: LayoutGrid, color: 'bg-[#FFB3C6] text-black', desc: 'Rearrange student height matrixes to neutralize Kuddus\'s sightline blindspots.' },
      { id: 'mission3', title: 'Mission 3: Syllabus Negotiator', icon: BookOpen, color: 'bg-[#6BCB77] text-black', desc: 'Loophole RAG dialogue engine. Extract critical cramming tips and export plans.' },
      { id: 'mission4', title: 'Mission 4: Tiffin Ledger', icon: Landmark, color: 'bg-orange-400 text-black', desc: 'Document extortion bills, washroom corridor permits, and caloric kinetic debt.' },
      { id: 'mission5', title: 'Mission 5: SOS Rescue Flare', icon: ShieldAlert, color: 'bg-[#FF6B6B] text-white', desc: 'Launch real-time alarms on active Kuddus patrols with offline cached synchronization.' },
      { id: 'mission6', title: 'Mission 6: Fact-Checker DB', icon: BadgeHelp, color: 'bg-[#8B5CF6] text-white', desc: 'Verify classroom myths. Run semantic checks on Harvard PhDs or pumpkin cording.' },
    ];

    // Stagger list variants
    const gridVariants = {
      hidden: { opacity: 0 },
      show: {
        opacity: 1,
        transition: { staggerChildren: 0.08 }
      }
    };

    const cardVariants = {
      hidden: { opacity: 0, y: 30, scale: 0.95 },
      show: { 
        opacity: 1, 
        y: 0, 
        scale: 1,
        transition: { type: 'spring', stiffness: 90, damping: 14 }
      }
    };

    return (
      <div className="space-y-8 py-4">
        {/* Animated Banner with Purple brutalist shadow */}
        <motion.div 
          initial={{ scale: 0.95, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: 'spring', stiffness: 100 }}
          className="bg-white border-4 border-black p-6 md:p-8 rounded-3xl shadow-[8px_8px_0px_0px_rgba(139,92,246,1)] relative overflow-hidden"
        >
          <div className="absolute right-4 top-4 opacity-15 hidden md:block">
            <Terminal className="w-24 h-24 text-[#8B5CF6]" />
          </div>
          <h2 className="font-display font-black text-2xl md:text-3xl text-black uppercase italic flex items-center gap-2">
            <Zap className="w-8 h-8 text-[#8B5CF6] animate-bounce" />
            <span>Active Rebellion Missions</span>
          </h2>
          <p className="font-sans text-zinc-700 text-sm md:text-base mt-2 font-semibold">
            Choose a digital disruptor module below to undermine Kuddus's authority and safeguard Class XII-B.
          </p>
        </motion.div>

        {/* Staggered Cards Grid */}
        <motion.div 
          variants={gridVariants}
          initial="hidden"
          animate="show"
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {list.map((item) => {
            const Icon = item.icon;
            return (
              <motion.div
                key={item.id}
                variants={cardVariants}
                whileHover={{ 
                  scale: 1.03, 
                  y: -6, 
                  shadow: '12px 12px 0px 0px rgba(139,92,246,1)' 
                }}
                whileTap={{ scale: 0.97 }}
                onClick={() => {
                  playBeep(330 + (list.findIndex(x => x.id === item.id) * 50), 'triangle', 0.15);
                  setCurrentTab(item.id);
                }}
                className="group border-4 border-black bg-white hover:bg-zinc-50 rounded-3xl p-6 shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] transition-all cursor-pointer flex flex-col justify-between relative overflow-hidden"
              >
                {/* Subtle Purple Accent shape in background of card */}
                <div className="absolute top-0 right-0 w-12 h-12 bg-[#8B5CF6]/5 rounded-bl-full transition-colors group-hover:bg-[#8B5CF6]/15" />

                <div className="space-y-4">
                  <div className={`inline-flex p-3 rounded-xl border-2 border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] ${item.color}`}>
                    <Icon className="w-6 h-6" />
                  </div>
                  <h3 className="font-display font-black text-xl text-black group-hover:text-[#8B5CF6] transition-colors leading-tight">
                    {item.title}
                  </h3>
                  <p className="font-sans text-zinc-600 text-sm leading-relaxed font-semibold">
                    {item.desc}
                  </p>
                </div>
                <div className="pt-4 mt-6 border-t-2 border-dashed border-zinc-200 flex justify-end font-display font-black text-xs text-black group-hover:translate-x-1 transition-transform">
                  Launch Console →
                </div>
              </motion.div>
            );
          })}
        </motion.div>
      </div>
    );
  };

  const activeSOSCount = alerts.filter(a => a.status === 'ACTIVE').length;

  return (
    <div className="min-h-screen bg-[#FDFCF0] text-[#2D3436] pb-12 flex flex-col relative overflow-hidden selection:bg-[#8B5CF6] selection:text-white">
      {/* Big Ambient Background Animation Blobs */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none z-0">
        <motion.div
          animate={{
            x: [0, 80, -40, 0],
            y: [0, -100, 50, 0],
            scale: [1, 1.25, 0.9, 1],
            rotate: [0, 180, 270, 360],
          }}
          transition={{
            duration: 25,
            repeat: Infinity,
            ease: "easeInOut",
          }}
          className="absolute -top-20 -left-20 w-96 h-96 rounded-full bg-[#FFB3C6]/15 blur-3xl"
        />
        <motion.div
          animate={{
            x: [0, -120, 60, 0],
            y: [0, 80, -120, 0],
            scale: [1, 1.15, 0.85, 1],
            rotate: [0, -270, 90, 0],
          }}
          transition={{
            duration: 30,
            repeat: Infinity,
            ease: "easeInOut",
          }}
          className="absolute top-1/3 -right-40 w-[500px] h-[500px] rounded-full bg-[#8B5CF6]/10 blur-3xl"
        />
        <motion.div
          animate={{
            x: [0, 60, -80, 0],
            y: [0, 120, -60, 0],
            scale: [0.9, 1.2, 1, 0.9],
          }}
          transition={{
            duration: 22,
            repeat: Infinity,
            ease: "easeInOut",
          }}
          className="absolute bottom-10 left-1/4 w-80 h-80 rounded-full bg-[#FFB3C6]/15 blur-3xl"
        />
      </div>

      {/* Dynamic Background Hacking Overlay Lines in Transparent Purple */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(139,92,246,0.015)_1px,transparent_1px),linear-gradient(90deg,rgba(139,92,246,0.015)_1px,transparent_1px)] bg-[size:32px_32px] pointer-events-none" />

      <Navbar 
        currentTab={currentTab} 
        setCurrentTab={setCurrentTab} 
        sosCount={activeSOSCount}
      />
      
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 md:px-6 pt-6 relative z-10">
        <AnimatePresence mode="wait">
          {renderContent()}
        </AnimatePresence>
      </main>
      
      {/* FLOATING INTERACTIVE PURPLE STICKER / REBELLION HUD WIDGET */}
      <div className="fixed bottom-14 right-6 z-50">
        <AnimatePresence>
          {isWidgetOpen && (
            <motion.div
              initial={{ opacity: 0, scale: 0.8, y: 50 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.8, y: 50 }}
              transition={{ type: 'spring', stiffness: 120, damping: 15 }}
              className="w-80 md:w-96 bg-white border-4 border-black rounded-3xl p-5 shadow-[10px_10px_0px_0px_rgba(0,0,0,1)] mb-4 space-y-4 relative"
            >
              {/* Header */}
              <div className="bg-[#8B5CF6] text-white border-4 border-black p-3 rounded-2xl flex items-center justify-between shadow-[2px_2px_0px_0px_rgba(2px,2px,2px,1)]">
                <div className="flex items-center gap-2">
                  <Terminal className="w-5 h-5 text-[#FFB3C6] animate-pulse" />
                  <span className="font-display font-black uppercase text-xs tracking-wider">XII-B SECRET HUD TERMINAL</span>
                </div>
                <button 
                  onClick={() => {
                    playBeep(220, 'square', 0.1);
                    setIsWidgetOpen(false);
                  }}
                  className="bg-black text-white hover:bg-zinc-800 p-1 rounded-md border-2 border-black cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Subtitle / Interactive audio buttons */}
              <div className="space-y-2">
                <span className="block text-[9px] uppercase font-mono font-black text-zinc-500">REBELLION CODES & BROADCASTER</span>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => {
                      playBeep(880, 'sine', 0.35);
                    }}
                    className="flex items-center justify-center gap-1 py-1.5 px-2.5 border-2 border-black bg-[#FDFCF0] hover:bg-[#8B5CF6] hover:text-white rounded-xl text-[10px] font-mono font-bold transition-all cursor-pointer shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]"
                  >
                    <Volume2 className="w-3.5 h-3.5 text-[#8B5CF6]" />
                    <span>880Hz Jammer</span>
                  </button>
                  <button
                    onClick={() => {
                      playBeep(1200, 'sawtooth', 0.5);
                    }}
                    className="flex items-center justify-center gap-1 py-1.5 px-2.5 border-2 border-black bg-[#FDFCF0] hover:bg-[#FF6B6B] hover:text-white rounded-xl text-[10px] font-mono font-bold transition-all cursor-pointer shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]"
                  >
                    <AlertOctagon className="w-3.5 h-3.5 text-[#FF6B6B]" />
                    <span>Sawtooth Alarm</span>
                  </button>
                </div>
              </div>

              {/* Encrypted Student Memo */}
              <div className="bg-[#8B5CF6]/10 border-2 border-[#8B5CF6] rounded-2xl p-4 space-y-2 relative overflow-hidden">
                <div className="flex items-center justify-between">
                  <span className="text-[9px] font-mono font-black text-[#8B5CF6] uppercase flex items-center gap-1">
                    <MessageSquare className="w-3.5 h-3.5" />
                    Encrypted Memo Logs
                  </span>
                  <span className="font-mono text-[8px] bg-[#8B5CF6] text-white px-1.5 py-0.5 rounded font-black">
                    {activeMemoIndex + 1}/{backbenchMemos.length}
                  </span>
                </div>
                <p className="font-sans text-xs font-semibold leading-relaxed text-black italic">
                  {backbenchMemos[activeMemoIndex]}
                </p>
                <button
                  onClick={() => {
                    playBeep(600, 'triangle', 0.08);
                    setActiveMemoIndex((prev) => (prev + 1) % backbenchMemos.length);
                  }}
                  className="w-full text-center font-mono text-[10px] text-[#8B5CF6] hover:underline font-black mt-2 uppercase cursor-pointer"
                >
                  Retrieve Next Encrypted Memo →
                </button>
              </div>

              {/* Aesthetic footnote */}
              <div className="text-[9px] font-mono font-black text-center text-zinc-400 uppercase tracking-widest">
                ⚙️ XII-B SANDBOX SECURITY BYPASS ACTIVE
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Floating Toggle Button - Custom Styled Purple Shape with motion layout */}
        <motion.button
          layout
          whileHover={{ scale: 1.1, rotate: 5 }}
          whileTap={{ scale: 0.9 }}
          onClick={() => {
            playBeep(isWidgetOpen ? 250 : 550, 'sine', 0.25);
            setIsWidgetOpen(!isWidgetOpen);
          }}
          className="w-14 h-14 bg-[#8B5CF6] border-4 border-black rounded-2xl flex items-center justify-center shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:bg-[#7C3AED] text-white cursor-pointer group relative overflow-hidden"
          title="Toggle Rebellion Control Room"
        >
          {/* Animated custom star shape rotated inside */}
          <motion.div
            animate={{ rotate: isWidgetOpen ? 45 : 0 }}
            className="flex items-center justify-center"
          >
            <Terminal className="w-6 h-6 stroke-[2.5]" />
          </motion.div>
          {/* Notification bubble if closed */}
          {!isWidgetOpen && (
            <span className="absolute top-1 right-1 w-3.5 h-3.5 bg-[#FF6B6B] border-2 border-black rounded-full animate-ping" />
          )}
        </motion.button>
      </div>

      <footer className="h-10 bg-black text-white flex items-center justify-between px-6 text-[10px] uppercase font-mono font-bold mt-12 border-t-4 border-black select-none shrink-0 relative z-20">
        <div className="flex gap-4">
          <span>● Server: Online</span>
          <span>● Resistance Members: 1,402</span>
          <span>● Mood: Rebellion</span>
        </div>
        <div className="animate-pulse text-[#8B5CF6] hidden sm:block">⚙️ SYSTEM OVERRIDE ACTIVE // SECTION XII-B ENCRYPTED</div>
      </footer>
    </div>
  );
}
