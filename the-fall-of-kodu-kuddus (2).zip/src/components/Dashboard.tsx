import React from 'react';
import { Complaint, Student, LedgerLog, SOSAlert } from '../types';
import { calculateCaloricDisparity } from '../utils';
import { LayoutDashboard, AlertTriangle, ShieldCheck, Landmark, Compass, Eye, ShieldAlert, Sparkles, TrendingUp } from 'lucide-react';
import { motion } from 'motion/react';

interface DashboardProps {
  complaints: Complaint[];
  students: Student[];
  logs: LedgerLog[];
  alerts: SOSAlert[];
  warningsCount: number;
  setCurrentTab: (tab: string) => void;
}

export default function Dashboard({
  complaints,
  students,
  logs,
  alerts,
  warningsCount,
  setCurrentTab,
}: DashboardProps) {
  
  // Math for Ledger Logs
  const totalTolls = logs.filter(l => l.type === 'toll').reduce((sum, l) => sum + l.amount, 0);
  const totalTiffins = logs.filter(l => l.type === 'tiffin').reduce((sum, l) => sum + l.amount, 0);
  const totalTaka = totalTolls + totalTiffins;

  // Caloric summation
  let totalCalories = 0;
  let totalRunKm = 0;
  logs.forEach(l => {
    const calc = calculateCaloricDisparity(l.description, l.amount);
    totalCalories += calc.calories;
    totalRunKm += calc.runDistanceKm;
  });

  // Math for SOS Alerts
  const activeSOS = alerts.filter(a => a.status === 'ACTIVE');

  // Math for Seating Efficiency
  const totalStudents = students.length;
  const initialBlockedSim = Math.round(totalStudents * 0.33);

  // Animation configuration
  const gridVariants = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.08
      }
    }
  };

  const cardVariants = {
    hidden: { opacity: 0, y: 20, scale: 0.98 },
    show: { 
      opacity: 1, 
      y: 0, 
      scale: 1,
      transition: { type: 'spring', stiffness: 100, damping: 15 }
    }
  };

  return (
    <motion.div 
      variants={gridVariants}
      initial="hidden"
      animate="show"
      className="space-y-8 py-4 text-[#2D3436]"
    >
      {/* Header Banner with Custom Purple Accents & Animation */}
      <motion.div 
        variants={cardVariants}
        className="bg-white border-4 border-black p-6 rounded-3xl shadow-[8px_8px_0px_0px_rgba(139,92,246,1)] flex flex-col md:flex-row items-center justify-between gap-4 relative overflow-hidden"
      >
        <div className="absolute top-0 right-0 w-32 h-32 bg-[#8B5CF6]/5 rounded-bl-full pointer-events-none" />
        <div className="relative z-10">
          <h2 className="font-display font-black text-2xl md:text-3xl flex items-center gap-3 text-black uppercase italic">
            <LayoutDashboard className="w-8 h-8 text-[#8B5CF6]" />
            <span>Rebel Command Central Dashboard</span>
          </h2>
          <p className="font-sans text-zinc-600 text-sm md:text-base mt-2 font-semibold">
            Real-time aggregate data feed from active student resistance networks. Fully encrypted out of Kuddus's tracking range.
          </p>
        </div>
        <motion.span 
          animate={{ scale: [1, 1.05, 1] }}
          transition={{ repeat: Infinity, duration: 2, ease: 'easeInOut' }}
          className="inline-flex items-center gap-2 bg-[#8B5CF6] border-4 border-black rounded-full px-5 py-2 font-mono text-xs text-white font-black shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] cursor-default"
        >
          <Sparkles className="w-4 h-4 text-[#FFB3C6] animate-spin" />
          <span>TRANSMISSION: ONLINE</span>
        </motion.span>
      </motion.div>

      {/* Main Stats Cards Bento Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        
        {/* Card 1: Warnings Meter */}
        <motion.div 
          variants={cardVariants}
          whileHover={{ y: -6, shadow: '10px 10px 0px 0px rgba(139,92,246,1)' }}
          className="bg-white border-4 border-black p-5 rounded-3xl shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] flex flex-col justify-between transition-shadow duration-200"
        >
          <div className="space-y-2.5">
            <span className="text-[10px] font-mono uppercase text-zinc-500 font-black block tracking-wider">Class Tension Gauge</span>
            <div className="flex items-center justify-between">
              <span className="font-display font-black text-xl text-black uppercase italic">Warnings</span>
              <span className={`font-mono text-sm font-black border-2 border-black px-2.5 py-0.5 rounded-lg ${
                warningsCount === 3 ? 'bg-[#FF6B6B] text-white animate-bounce' : 'bg-[#FFB3C6] text-black'
              }`}>
                {warningsCount}/3
              </span>
            </div>
            {/* Horizontal Mini progress bar */}
            <div className="h-5 bg-zinc-100 border-2 border-black rounded-lg overflow-hidden relative">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${(warningsCount / 3) * 100}%` }}
                transition={{ duration: 0.8, ease: 'easeOut' }}
                className={`h-full ${
                  warningsCount === 1 ? 'bg-[#FFB3C6]' :
                  warningsCount === 2 ? 'bg-orange-500' :
                  warningsCount === 3 ? 'bg-[#FF6B6B] animate-pulse' : 'bg-[#6BCB77]'
                }`}
              />
            </div>
          </div>
          <button 
            onClick={() => setCurrentTab('mission1')}
            className="mt-4 text-left font-display font-black text-xs text-[#8B5CF6] hover:text-[#7C3AED] hover:underline uppercase flex items-center gap-1.5 cursor-pointer transition-colors"
          >
            Manage Warnings <Compass className="w-4 h-4 text-[#8B5CF6] animate-spin-slow" />
          </button>
        </motion.div>

        {/* Card 2: Extorted Funds with purple shadow */}
        <motion.div 
          variants={cardVariants}
          whileHover={{ y: -4, shadow: '8px 8px 0px 0px rgba(139,92,246,1)' }}
          className="bg-white border-4 border-black p-5 rounded-3xl shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] flex flex-col justify-between"
        >
          <div className="space-y-2">
            <span className="text-[10px] font-mono uppercase text-zinc-500 font-black block tracking-wider">Aggregate Extorted Bribes</span>
            <span className="font-display font-black text-3xl text-black block">৳{totalTaka}</span>
            <div className="text-xs text-zinc-600 space-y-1 font-semibold">
              <p>• Washroom Corridor Tolls: <span className="font-mono font-bold text-[#8B5CF6]">৳{totalTolls}</span></p>
              <p>• Stolen Backbench Tiffin: <span className="font-mono font-bold text-[#FF6B6B]">৳{totalTiffins}</span></p>
            </div>
          </div>
          <button 
            onClick={() => setCurrentTab('mission4')}
            className="mt-4 text-left font-display font-black text-xs text-orange-600 hover:underline uppercase flex items-center gap-1.5 cursor-pointer"
          >
            Audit Corruption Ledger <Landmark className="w-4 h-4 text-orange-600" />
          </button>
        </motion.div>

        {/* Card 3: Seating Line of Sight with purple shadow */}
        <motion.div 
          variants={cardVariants}
          whileHover={{ y: -4, shadow: '8px 8px 0px 0px rgba(139,92,246,1)' }}
          className="bg-white border-4 border-black p-5 rounded-3xl shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] flex flex-col justify-between"
        >
          <div className="space-y-2">
            <span className="text-[10px] font-mono uppercase text-zinc-500 font-black block tracking-wider">Sightline Blindspots</span>
            <span className="font-display font-black text-xl text-black uppercase italic block">Camouflage Plan</span>
            <div className="text-xs text-zinc-600 space-y-1 font-semibold">
              <p>• Enrolled Rebels: <span className="font-mono font-bold text-[#8B5CF6]">{totalStudents}</span></p>
              <p>• Base Protected: <span className="font-mono font-bold text-emerald-600">{initialBlockedSim} students</span></p>
            </div>
          </div>
          <button 
            onClick={() => setCurrentTab('mission2')}
            className="mt-4 text-left font-display font-black text-xs text-purple-600 hover:underline uppercase flex items-center gap-1.5 cursor-pointer"
          >
            Optimize Classroom Grid <Eye className="w-4 h-4 text-purple-600" />
          </button>
        </motion.div>

        {/* Card 4: Active SOS Alarms */}
        <motion.div 
          variants={cardVariants}
          whileHover={{ y: -4, shadow: '8px 8px 0px 0px rgba(139,92,246,1)' }}
          className="bg-white border-4 border-black p-5 rounded-3xl shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] flex flex-col justify-between"
        >
          <div className="space-y-2">
            <span className="text-[10px] font-mono uppercase text-zinc-500 font-black block tracking-wider">Active Patrol Flares</span>
            <span className={`font-display font-black text-2xl block uppercase italic ${activeSOS.length > 0 ? 'text-[#FF6B6B] animate-pulse' : 'text-[#2D3436]'}`}>
              {activeSOS.length} SIGHTED
            </span>
            <div className="text-xs text-zinc-600 space-y-1 font-semibold">
              <p>• Offline cache syncs: <span className="font-mono font-bold text-emerald-600">Active</span></p>
              <p>• Total alerts recorded: <span className="font-mono font-bold text-black">{alerts.length}</span></p>
            </div>
          </div>
          <button 
            onClick={() => setCurrentTab('sos')}
            className="mt-4 text-left font-display font-black text-xs text-[#FF6B6B] hover:underline uppercase flex items-center gap-1.5 cursor-pointer"
          >
            Open SOS Beacon Deck <ShieldAlert className="w-4 h-4 text-[#FF6B6B]" />
          </button>
        </motion.div>

      </div>

      {/* Second Row Layout: Extortion Chart + Active Alarms Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Side: Economic Extortion custom SVG Chart, styled with rich purple theme */}
        <motion.div 
          variants={cardVariants}
          className="lg:col-span-7 bg-white border-4 border-black p-6 rounded-3xl shadow-[8px_8px_0px_0px_rgba(139,92,246,1)] space-y-4"
        >
          <h3 className="font-display font-black text-lg text-black flex items-center gap-2 uppercase italic">
            <TrendingUp className="w-5 h-5 text-[#8B5CF6]" />
            <span>Extortion Economy Distribution (BBackb)</span>
          </h3>

          <div className="bg-zinc-50 border-4 border-black p-4 rounded-2xl relative overflow-hidden">
            <div className="absolute -right-4 -bottom-4 w-16 h-16 bg-[#8B5CF6]/5 rounded-full pointer-events-none" />
            {totalTaka === 0 ? (
              <p className="text-zinc-400 italic text-center py-8 font-sans text-xs">No extortions logged in the ledger yet.</p>
            ) : (
              <div className="space-y-6">
                {/* SVG Bar Visualization with spring-animated grows */}
                <div className="h-[160px] flex items-end justify-around pb-2 border-b-4 border-black relative">
                  <div className="absolute top-0 left-0 right-0 border-t border-zinc-200" />
                  <div className="absolute top-1/2 left-0 right-0 border-t border-zinc-200" />

                  {/* Tolls bar in violet/purple */}
                  <div className="flex flex-col items-center gap-1.5 w-1/3">
                    <span className="font-mono text-sm font-black text-[#8B5CF6]">৳{totalTolls}</span>
                    <motion.div 
                      initial={{ height: 0 }}
                      animate={{ height: `${Math.max(15, (totalTolls / totalTaka) * 110)}px` }}
                      transition={{ type: 'spring', stiffness: 80, delay: 0.1 }}
                      className="w-20 bg-[#8B5CF6] border-4 border-black rounded-t-xl shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]"
                    />
                    <span className="font-display font-black text-[11px] text-black uppercase mt-1">Washroom Tolls</span>
                  </div>

                  {/* Tiffins bar in deep coral */}
                  <div className="flex flex-col items-center gap-1.5 w-1/3">
                    <span className="font-mono text-sm font-black text-[#FF6B6B]">৳{totalTiffins}</span>
                    <motion.div 
                      initial={{ height: 0 }}
                      animate={{ height: `${Math.max(15, (totalTiffins / totalTaka) * 110)}px` }}
                      transition={{ type: 'spring', stiffness: 80, delay: 0.2 }}
                      className="w-20 bg-[#FF6B6B] border-4 border-black rounded-t-xl shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]"
                    />
                    <span className="font-display font-black text-[11px] text-black uppercase mt-1">Stolen Tiffin</span>
                  </div>
                </div>

                {/* Caloric conversion ticker */}
                <div className="flex flex-col md:flex-row md:items-center justify-between text-xs font-mono bg-purple-50 border-2 border-[#8B5CF6] p-3.5 rounded-xl text-purple-950 font-black gap-2">
                  <span className="flex items-center gap-1">🔋 METABOLIC CALORIC LOSS: {totalCalories} Kcal</span>
                  <span className="flex items-center gap-1">🏃 ESCAPE FLIGHT PENALTY: {totalRunKm.toFixed(1)} Km</span>
                </div>
              </div>
            )}
          </div>
        </motion.div>

        {/* Right Side: Emergency active alarms panel with customized scrollbar */}
        <motion.div 
          variants={cardVariants}
          className="lg:col-span-5 bg-white border-4 border-black p-6 rounded-3xl shadow-[8px_8px_0px_0px_rgba(139,92,246,1)] space-y-4 flex flex-col justify-between"
        >
          <div className="space-y-4">
            <h3 className="font-display font-black text-lg text-black flex items-center gap-2 uppercase italic">
              <AlertTriangle className="w-5 h-5 text-[#8B5CF6] animate-pulse" />
              <span>Resistance Active Patrols</span>
            </h3>

            <div className="space-y-3 max-h-[220px] overflow-y-auto pr-1">
              {activeSOS.length === 0 ? (
                <div className="border-4 border-dashed border-zinc-200 py-12 rounded-2xl text-center text-zinc-400 font-sans text-xs font-bold italic">
                  All coordinates silent. No active Kuddus patrols sighted in Section B.
                </div>
              ) : (
                activeSOS.map((alert) => (
                  <motion.div 
                    initial={{ scale: 0.95, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    key={alert.id} 
                    className="border-2 border-black p-3.5 rounded-2xl bg-purple-50/50 text-xs space-y-1.5 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-display font-black text-purple-900 uppercase">📍 {alert.location}</span>
                      <span className="font-mono text-[9px] text-zinc-500 font-bold">{alert.timestamp}</span>
                    </div>
                    <p className="font-sans font-semibold text-zinc-800 italic">"{alert.message}"</p>
                    <div className="flex justify-between items-center text-[9px] pt-1.5 border-t border-purple-100 font-bold">
                      <span className="font-mono text-zinc-500">Rep: {alert.reporter}</span>
                      <button
                        onClick={() => setCurrentTab('sos')}
                        className="text-[#8B5CF6] hover:underline font-black uppercase"
                      >
                        Resolve Flare →
                      </button>
                    </div>
                  </motion.div>
                ))
              )}
            </div>
          </div>
          
          <div className="pt-4 border-t-2 border-dashed border-zinc-200 text-[10px] font-mono text-zinc-400 uppercase font-bold text-center">
            📡 AUTO-CACHED WITH HEADQUARTERS MATRIX
          </div>
        </motion.div>

      </div>

      {/* Rebel Action Grid Launcher Quick Links with purple visual themes */}
      <motion.div 
        variants={cardVariants}
        className="bg-white border-4 border-black p-6 rounded-3xl shadow-[8px_8px_0px_0px_rgba(139,92,246,1)] space-y-4"
      >
        <h3 className="font-display font-black text-lg text-black uppercase italic">Resistance Module Quick Command Launcher</h3>
        
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 text-center">
          <motion.button
            whileHover={{ scale: 1.05, y: -2 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setCurrentTab('mission1')}
            className="p-4 border-2 border-black bg-[#4D96FF]/10 hover:bg-[#4D96FF]/20 text-[#4D96FF] rounded-2xl font-display font-black text-xs shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] cursor-pointer"
          >
            📩 Complaint Tunnel
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.05, y: -2 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setCurrentTab('mission2')}
            className="p-4 border-2 border-black bg-[#8B5CF6]/10 hover:bg-[#8B5CF6]/20 text-[#8B5CF6] rounded-2xl font-display font-black text-xs shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] cursor-pointer"
          >
            🪑 Seat Planner
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.05, y: -2 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setCurrentTab('mission3')}
            className="p-4 border-2 border-black bg-[#6BCB77]/10 hover:bg-[#6BCB77]/20 text-emerald-800 rounded-2xl font-display font-black text-xs shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] cursor-pointer"
          >
            📚 Syllabus Negotiator
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.05, y: -2 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setCurrentTab('mission4')}
            className="p-4 border-2 border-black bg-orange-50 hover:bg-orange-100 text-orange-950 rounded-2xl font-display font-black text-xs shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] cursor-pointer"
          >
            📋 Extortion Ledger
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.05, y: -2 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setCurrentTab('sos')}
            className="p-4 border-2 border-black bg-[#FF6B6B]/10 hover:bg-[#FF6B6B]/20 text-[#FF6B6B] rounded-2xl font-display font-black text-xs shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] cursor-pointer"
          >
            🚨 SOS Flare
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.05, y: -2 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setCurrentTab('mission6')}
            className="p-4 border-2 border-black bg-purple-50 hover:bg-purple-100 text-[#8B5CF6] rounded-2xl font-display font-black text-xs shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] cursor-pointer"
          >
            🔍 Fact-Checker
          </motion.button>
        </div>
      </motion.div>

    </motion.div>
  );
}
