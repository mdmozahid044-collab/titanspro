import React, { useState } from 'react';
import { LedgerLog } from '../types';
import { calculateCaloricDisparity } from '../utils';
import { Landmark, Plus, Trash2, ShieldAlert, Award, ChevronRight, Activity, DollarSign } from 'lucide-react';
import { motion } from 'motion/react';

interface Mission4LedgerProps {
  logs: LedgerLog[];
  addLog: (l: LedgerLog) => void;
  removeLog: (id: string) => void;
}

export default function Mission4Ledger({ logs, addLog, removeLog }: Mission4LedgerProps) {
  // Form states
  const [type, setType] = useState<'toll' | 'tiffin'>('tiffin');
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState(50);
  const [victim, setVictim] = useState('');
  const [perpetrator, setPerpetrator] = useState('Head Monitor');

  // Interactive conversion tool state
  const [convertAmount, setConvertAmount] = useState(100);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!description.trim() || !victim.trim()) return;

    const newLog: LedgerLog = {
      id: 'l' + (logs.length + 1),
      type,
      description: description.trim(),
      amount: Number(amount),
      victim: victim.trim(),
      perpetrator,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
    };

    addLog(newLog);
    setDescription('');
    setVictim('');
    setAmount(50);
  };

  // Math totals
  const totalTolls = logs.filter(l => l.type === 'toll').reduce((sum, l) => sum + l.amount, 0);
  const totalTiffins = logs.filter(l => l.type === 'tiffin').reduce((sum, l) => sum + l.amount, 0);
  const totalTaka = totalTolls + totalTiffins;

  // Run all current logs through caloric engine
  let cumulativeCalories = 0;
  let cumulativeRunDist = 0;
  let cumulativePushups = 0;

  logs.forEach(l => {
    const calc = calculateCaloricDisparity(l.description, l.amount);
    cumulativeCalories += calc.calories;
    cumulativeRunDist += calc.runDistanceKm;
    cumulativePushups += calc.pushupsNeeded;
  });

  // Active conversions for interactive converter
  const conversionResult = calculateCaloricDisparity('Direct conversion', convertAmount);

  return (
    <div className="space-y-8 py-4 animate-fadeIn text-[#2D3436]">
      {/* Header Banner */}
      <div className="bg-[#FFB3C6] text-black border-4 border-black p-6 rounded-3xl shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]">
        <h2 className="font-display font-black text-2xl md:text-3xl flex items-center gap-3 uppercase italic">
          <Landmark className="w-8 h-8 text-black" />
          <span>Mission 4: Corrupt Economy & Tiffin Ledger</span>
        </h2>
        <p className="font-sans text-black/80 text-sm md:text-base mt-2 font-medium">
          Document extortion rates, audit corridor bribes, and translate fiscal damages into physical caloric debt metrics.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Log inputs & lists */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Economic Offense Logger */}
          <div className="bg-white border-4 border-black p-6 rounded-3xl shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] space-y-4">
            <h3 className="font-display font-black text-lg text-black flex items-center gap-2 uppercase italic">
              <Plus className="w-5 h-5 text-[#FF6B6B]" />
              <span>Log Corrupt Incident</span>
            </h3>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <motion.button
                  type="button"
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.97 }}
                  onClick={() => setType('tiffin')}
                  className={`py-3 px-4 border-2 border-black rounded-xl font-display font-black text-sm transition-all cursor-pointer ${
                    type === 'tiffin'
                      ? 'bg-[#FFB3C6] text-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] translate-y-[-2px]'
                      : 'bg-white hover:bg-zinc-50 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]'
                  }`}
                >
                  🍔 Stolen Tiffin
                </motion.button>
                <motion.button
                  type="button"
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.97 }}
                  onClick={() => setType('toll')}
                  className={`py-3 px-4 border-2 border-black rounded-xl font-display font-black text-sm transition-all cursor-pointer ${
                    type === 'toll'
                      ? 'bg-[#FFB3C6] text-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] translate-y-[-2px]'
                      : 'bg-white hover:bg-zinc-50 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]'
                  }`}
                >
                  🚻 Washroom Toll
                </motion.button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="block text-[10px] uppercase font-bold text-zinc-500">Victim (Student Name)</label>
                  <input
                    type="text"
                    placeholder="e.g. Mitu Paul"
                    value={victim}
                    onChange={(e) => setVictim(e.target.value)}
                    required
                    className="w-full border-2 border-black rounded-xl px-3 py-2 bg-zinc-50 text-sm focus:outline-none focus:bg-white"
                  />
                </div>
                <div className="space-y-1">
                  <label className="block text-[10px] uppercase font-bold text-zinc-500">Perpetrator Authority</label>
                  <select
                    value={perpetrator}
                    onChange={(e) => setPerpetrator(e.target.value)}
                    className="w-full border-2 border-black rounded-xl px-3 py-2 bg-zinc-50 text-sm focus:outline-none"
                  >
                    <option>Head Monitor</option>
                    <option>Class Captain (Loyalist)</option>
                    <option>Kuddus Patrol Guild</option>
                    <option>Kodu Kuddus Himself</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="md:col-span-3 space-y-1">
                  <label className="block text-[10px] uppercase font-bold text-zinc-500">Item Description</label>
                  <input
                    type="text"
                    placeholder="e.g. Chicken roll confiscation or bathroom permit fee"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    required
                    className="w-full border-2 border-black rounded-xl px-3 py-2 bg-zinc-50 text-sm focus:outline-none focus:bg-white"
                  />
                </div>
                <div className="space-y-1">
                  <label className="block text-[10px] uppercase font-bold text-zinc-500">Taka Value (৳)</label>
                  <input
                    type="number"
                    min={2}
                    max={500}
                    value={amount}
                    onChange={(e) => setAmount(Number(e.target.value))}
                    required
                    className="w-full border-2 border-black rounded-xl px-3 py-2 bg-zinc-50 text-sm font-mono font-bold focus:outline-none focus:bg-white"
                  />
                </div>
              </div>

              <motion.button
                type="submit"
                whileHover={{ scale: 1.04, y: -2, shadow: '6px 6px 0px 0px rgba(255,179,198,1)' }}
                whileTap={{ scale: 0.96 }}
                className="w-full bg-black text-[#FFB3C6] py-3 rounded-xl font-display font-black text-sm border-2 border-black shadow-[4px_4px_0px_0px_rgba(255,179,198,1)] transition-all cursor-pointer uppercase tracking-wider"
              >
                File Corrupt Log Entry
              </motion.button>
            </form>
          </div>

          {/* Ledger logs stream */}
          <div className="bg-white border-4 border-black p-6 rounded-3xl shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] space-y-4">
            <h3 className="font-display font-black text-lg text-black flex items-center justify-between uppercase italic">
              <span>Audited Corrupt Logs</span>
              <span className="font-mono text-xs bg-[#FDFCF0] border-2 border-black rounded-lg px-2.5 py-0.5 font-bold text-black">
                {logs.length} Entries
              </span>
            </h3>

            <div className="space-y-3 max-h-[380px] overflow-y-auto pr-1">
              {logs.map((log) => {
                const disparity = calculateCaloricDisparity(log.description, log.amount);
                return (
                  <div key={log.id} className="border-2 border-black p-4 rounded-xl bg-[#FDFCF0] hover:bg-zinc-50 transition-colors flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
                    <div className="space-y-1 flex-1">
                      <div className="flex items-center gap-2">
                        <span className={`px-2 py-0.5 rounded-lg font-mono text-[9px] border-2 border-black font-black uppercase ${
                          log.type === 'tiffin' ? 'bg-[#FF6B6B]/20 text-[#FF6B6B]' : 'bg-[#4D96FF]/20 text-[#4D96FF]'
                        }`}>
                          {log.type === 'tiffin' ? '🍔 TIFFIN' : '🚻 TOLL'}
                        </span>
                        <span className="font-mono text-[10px] text-zinc-500 font-bold">#{log.id} • {log.timestamp}</span>
                      </div>
                      
                      <h4 className="font-display font-black text-sm text-black">{log.description}</h4>
                      
                      <div className="text-xs text-zinc-700 space-y-0.5 font-medium">
                        <p>👤 <span className="font-bold text-black uppercase text-[10px]">Victim:</span> {log.victim} • <span className="font-bold text-black uppercase text-[10px]">Perp:</span> {log.perpetrator}</p>
                        <p className="font-mono text-[10px] text-zinc-500">
                          ⚡ Caloric Loss: <span className="text-[#FF6B6B] font-bold">{disparity.calories} kcal</span> • Run Penalty: <span className="text-[#4D96FF] font-bold">{disparity.runDistanceKm} km</span>
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-4 border-t-2 md:border-t-0 md:border-l-2 border-dashed border-black pt-3 md:pt-0 md:pl-4">
                      <div className="text-right">
                        <span className="block text-[10px] font-mono text-zinc-500 font-bold">DAMAGE</span>
                        <span className="font-display font-black text-xl text-black">৳{log.amount}</span>
                      </div>
                      <button
                        onClick={() => removeLog(log.id)}
                        className="text-red-500 hover:text-white hover:bg-[#FF6B6B] border-2 border-transparent hover:border-black p-1.5 rounded-lg transition-all cursor-pointer"
                        title="Erase Log entry"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

        </div>

        {/* Right Column: Visual Charts & Conversion Calculator */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* Data Visualizations (Custom SVG Neo-Brutalist Charts) */}
          <div className="bg-white border-4 border-black p-6 rounded-3xl shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] space-y-6">
            <h3 className="font-display font-black text-lg text-black flex items-center gap-2 uppercase italic">
              <Activity className="w-5 h-5 text-[#FF6B6B]" />
              <span>Extortion Distribution Chart</span>
            </h3>

            {/* Custom SVG Bar Chart comparing Toll vs Tiffin */}
            <div className="space-y-4">
              <div className="bg-[#FDFCF0] border-2 border-black p-4 rounded-2xl">
                <span className="block text-xs font-mono text-black font-bold uppercase mb-3">Total Extorted: ৳{totalTaka}</span>
                
                {/* SVG Bar Visualization */}
                <div className="h-[120px] flex items-end justify-around pb-2 border-b-2 border-black relative">
                  
                  {/* Grid Lines */}
                  <div className="absolute top-0 left-0 right-0 border-t border-zinc-200" />
                  <div className="absolute top-1/3 left-0 right-0 border-t border-zinc-200" />
                  <div className="absolute top-2/3 left-0 right-0 border-t border-zinc-200" />

                  {/* Tolls bar */}
                  <div className="flex flex-col items-center gap-1 w-1/3 z-10">
                    <span className="font-mono text-[10px] font-black text-[#4D96FF]">৳{totalTolls}</span>
                    <div 
                      className="w-12 bg-[#4D96FF] border-2 border-black rounded-t-lg transition-all duration-500 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]"
                      style={{ 
                        height: totalTaka > 0 ? `${Math.max(10, (totalTolls / totalTaka) * 80)}px` : '10px' 
                      }}
                    />
                    <span className="font-display font-black text-[9px] text-zinc-800 uppercase mt-1">Washroom Tolls</span>
                  </div>

                  {/* Tiffins bar */}
                  <div className="flex flex-col items-center gap-1 w-1/3 z-10">
                    <span className="font-mono text-[10px] font-black text-[#FF6B6B]">৳{totalTiffins}</span>
                    <div 
                      className="w-12 bg-[#FF6B6B] border-2 border-black rounded-t-lg transition-all duration-500 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]"
                      style={{ 
                        height: totalTaka > 0 ? `${Math.max(10, (totalTiffins / totalTaka) * 80)}px` : '10px' 
                      }}
                    />
                    <span className="font-display font-black text-[9px] text-zinc-800 uppercase mt-1">Stolen Tiffins</span>
                  </div>

                </div>
              </div>
            </div>
          </div>

          {/* Caloric vs Kinetic Disparity Engine */}
          <div className="bg-white border-4 border-black p-6 rounded-3xl shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] space-y-4">
            <h3 className="font-display font-black text-lg text-black flex items-center gap-2 uppercase italic">
              <Award className="w-5 h-5 text-[#FFB3C6] animate-pulse" />
              <span>Caloric Disparity Engine</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="bg-[#FF6B6B]/10 border-2 border-black p-3 rounded-xl text-center shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
                <span className="block text-[8px] font-mono text-black font-bold uppercase">Extorted Fuel</span>
                <span className="font-display font-black text-sm text-[#FF6B6B]">{cumulativeCalories} kcal</span>
              </div>
              <div className="bg-[#4D96FF]/10 border-2 border-black p-3 rounded-xl text-center shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
                <span className="block text-[8px] font-mono text-black font-bold uppercase">Sprint Escape</span>
                <span className="font-display font-black text-sm text-[#4D96FF]">{cumulativeRunDist.toFixed(1)} km</span>
              </div>
              <div className="bg-[#FFB3C6]/15 border-2 border-black p-3 rounded-xl text-center shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
                <span className="block text-[8px] font-mono text-black font-bold uppercase">Calisthenic Debt</span>
                <span className="font-display font-black text-sm text-pink-600 font-bold">{cumulativePushups} Reps</span>
              </div>
            </div>

            <p className="font-sans text-xs text-zinc-700 leading-relaxed bg-[#FDFCF0] border-2 border-black p-3 rounded-xl font-medium">
              📚 <span className="font-bold text-black">Audit Insight</span>: Kuddus's regime has extorted energy equal to <span className="font-bold text-black">{cumulativePushups} pushups</span> of physical workload. To offset this loss and keep classroom metabolic sync, rebels must optimize food distribution immediately.
            </p>
          </div>

          {/* Interactive Bribe Currency Converter */}
          <div className="bg-white border-4 border-black p-6 rounded-3xl shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] space-y-4">
            <h3 className="font-display font-black text-lg text-black flex items-center gap-2 uppercase italic">
              <DollarSign className="w-5 h-5 text-[#6BCB77]" />
              <span>Tiffin Exchange Rate Calculator</span>
            </h3>

            <div className="space-y-3">
              <div className="space-y-1">
                <label className="block text-[10px] uppercase font-bold text-zinc-500">Bribe Value in Taka (৳)</label>
                <input
                  type="number"
                  min={5}
                  max={1000}
                  value={convertAmount}
                  onChange={(e) => setConvertAmount(Number(e.target.value))}
                  className="w-full border-2 border-black rounded-xl px-2.5 py-1.5 bg-zinc-50 font-mono text-sm font-bold focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="bg-zinc-50 border-2 border-black p-2.5 rounded-xl flex items-center justify-between">
                  <span className="text-zinc-500 font-mono font-bold">Samosas 🥟:</span>
                  <span className="font-bold font-mono text-black">{conversionResult.samosaEquiv}</span>
                </div>
                <div className="bg-zinc-50 border-2 border-black p-2.5 rounded-xl flex items-center justify-between">
                  <span className="text-zinc-500 font-mono font-bold">Singaras 🥟:</span>
                  <span className="font-bold font-mono text-black">{conversionResult.singaraEquiv}</span>
                </div>
                <div className="bg-zinc-50 border-2 border-black p-2.5 rounded-xl flex items-center justify-between">
                  <span className="text-zinc-500 font-mono font-bold">Tiffin Creds:</span>
                  <span className="font-bold font-mono text-zinc-800">{conversionResult.tiffinCredits}</span>
                </div>
                <div className="bg-zinc-50 border-2 border-black p-2.5 rounded-xl flex items-center justify-between font-bold">
                  <span className="text-zinc-500 font-mono font-bold">Calories 🍫:</span>
                  <span className="font-bold font-mono text-[#FF6B6B]">{conversionResult.calories} kcal</span>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
