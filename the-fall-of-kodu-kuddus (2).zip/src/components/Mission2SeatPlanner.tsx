import React, { useState, useEffect } from 'react';
import { Student, Seat } from '../types';
import { evaluateLineOfSight, optimizeSeating } from '../utils';
import { LayoutGrid, Plus, Users, User, ArrowDown, Sparkles, HelpCircle, Eye, EyeOff, RotateCcw } from 'lucide-react';
import { motion } from 'motion/react';

interface Mission2SeatPlannerProps {
  students: Student[];
  setStudents: React.Dispatch<React.SetStateAction<Student[]>>;
}

export default function Mission2SeatPlanner({ students, setStudents }: Mission2SeatPlannerProps) {
  const [rows, setRows] = useState(4);
  const [cols, setCols] = useState(3);
  const [grid, setGrid] = useState<Seat[][]>([]);
  const [selectedSeat, setSelectedSeat] = useState<{ r: number; c: number } | null>(null);

  // Form states for new student
  const [newName, setNewName] = useState('');
  const [newRoll, setNewRoll] = useState('');
  const [newHeight, setNewHeight] = useState(165);

  // Initialize and evaluate grid based on current students and dimensions
  useEffect(() => {
    // Fill the grid based on rows and columns
    const initialGrid: Seat[][] = Array.from({ length: rows }, (_, r) =>
      Array.from({ length: cols }, (_, c) => {
        const studentIndex = r * cols + c;
        const student = studentIndex < students.length ? students[studentIndex] : null;
        return {
          student,
          row: r,
          col: c,
        };
      })
    );
    setGrid(evaluateLineOfSight(initialGrid));
  }, [students, rows, cols]);

  const handleAddStudent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim() || !newRoll.trim()) return;

    // Check if roll already exists
    if (students.some(s => s.roll === newRoll.trim())) {
      alert("Error: Student with this roll number is already in the class ledger!");
      return;
    }

    const newStudent: Student = {
      id: 's' + (students.length + 1),
      name: newName.trim(),
      roll: newRoll.trim(),
      height: Number(newHeight),
    };

    setStudents([...students, newStudent]);
    setNewName('');
    setNewRoll('');
    setNewHeight(165);
  };

  const handleRemoveStudent = (id: string) => {
    setStudents(students.filter(s => s.id !== id));
  };

  const handleResetLedger = () => {
    if (confirm("Reset class student list to default?")) {
      // Revert to initial
      window.location.reload(); // Quick reset
    }
  };

  const triggerOptimization = () => {
    const optimized = optimizeSeating(students, rows, cols);
    // Sync the student state to represent the sorted layout if desired,
    // or just overwrite the rendered grid. Let's sync the student array
    // sorted by height so that it is persisted everywhere!
    const sorted = [...students].sort((a, b) => a.height - b.height);
    setStudents(sorted);
  };

  // Manual swap of two desks
  const handleSeatClick = (r: number, c: number) => {
    if (!selectedSeat) {
      setSelectedSeat({ r, c });
    } else {
      // Perform manual swap
      const newGrid = [...grid.map(row => row.map(cell => ({ ...cell })))];
      const s1 = newGrid[selectedSeat.r][selectedSeat.c].student;
      const s2 = newGrid[r][c].student;

      newGrid[selectedSeat.r][selectedSeat.c].student = s2;
      newGrid[r][c].student = s1;

      // Re-evaluate line of sight for the manual swap
      setGrid(evaluateLineOfSight(newGrid));
      setSelectedSeat(null);

      // Reconstruct the student flat array based on the manual grid
      const updatedStudentsList: Student[] = [];
      for (let gridR = 0; gridR < rows; gridR++) {
        for (let gridC = 0; gridC < cols; gridC++) {
          const s = newGrid[gridR][gridC].student;
          if (s) updatedStudentsList.push(s);
        }
      }
      
      // Let's also include students that might be overflowing the grid
      students.forEach(originalStudent => {
        if (!updatedStudentsList.some(s => s.id === originalStudent.id)) {
          updatedStudentsList.push(originalStudent);
        }
      });

      setStudents(updatedStudentsList);
    }
  };

  // Compute metrics
  const totalGridCapacity = rows * cols;
  const studentsInGrid = grid.flat().filter(cell => cell.student !== null).length;
  const blockedCount = grid.flat().filter(cell => cell.student !== null && cell.isBlocked).length;
  const clearCount = studentsInGrid - blockedCount;
  const efficiency = studentsInGrid > 0 ? Math.round((clearCount / studentsInGrid) * 100) : 100;

  return (
    <div className="space-y-8 py-4 animate-fadeIn text-[#2D3436]">
      {/* Header Banner */}
      <div className="bg-[#FFB3C6] text-black border-4 border-black p-6 rounded-3xl shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]">
        <h2 className="font-display font-black text-2xl md:text-3xl flex items-center gap-3 uppercase italic">
          <LayoutGrid className="w-8 h-8 text-black" />
          <span>Mission 2: Anti-Camouflage Seat Planner</span>
        </h2>
        <p className="font-sans text-black/80 text-sm md:text-base mt-2 font-medium">
          Rearrange students to disrupt Kuddus's physical visual shield. Minimize blind spots and optimize classroom sightlines.
        </p>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-12 gap-8">
        
        {/* Left Column: Grid dimensions & Classroom visualizer */}
        <div className="xl:col-span-8 space-y-6">
          <div className="bg-white border-4 border-black p-6 rounded-3xl shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] space-y-6">
            
            {/* Controls panel */}
            <div className="flex flex-wrap items-center justify-between gap-4 bg-[#FFB3C6]/10 p-4 border-2 border-black rounded-2xl">
              <div className="flex items-center gap-4">
                <div className="space-y-1">
                  <span className="block text-[10px] font-mono font-bold text-zinc-500 uppercase">Rows</span>
                  <div className="flex items-center gap-1.5">
                    <motion.button 
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                      onClick={() => setRows(Math.max(2, rows - 1))}
                      className="w-8 h-8 bg-white border-2 border-black rounded-lg font-black hover:bg-zinc-100 cursor-pointer shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]"
                    >
                      -
                    </motion.button>
                    <span className="font-display font-black text-base w-6 text-center">{rows}</span>
                    <motion.button 
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                      onClick={() => setRows(Math.min(6, rows + 1))}
                      className="w-8 h-8 bg-white border-2 border-black rounded-lg font-black hover:bg-zinc-100 cursor-pointer shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]"
                    >
                      +
                    </motion.button>
                  </div>
                </div>

                <div className="space-y-1">
                  <span className="block text-[10px] font-mono font-bold text-zinc-500 uppercase">Columns</span>
                  <div className="flex items-center gap-1.5">
                    <motion.button 
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                      onClick={() => setCols(Math.max(2, cols - 1))}
                      className="w-8 h-8 bg-white border-2 border-black rounded-lg font-black hover:bg-zinc-100 cursor-pointer shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]"
                    >
                      -
                    </motion.button>
                    <span className="font-display font-black text-base w-6 text-center">{cols}</span>
                    <motion.button 
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                      onClick={() => setCols(Math.min(6, cols + 1))}
                      className="w-8 h-8 bg-white border-2 border-black rounded-lg font-black hover:bg-zinc-100 cursor-pointer shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]"
                    >
                      +
                    </motion.button>
                  </div>
                </div>
              </div>

              <div className="flex gap-2">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={triggerOptimization}
                  className="bg-[#6BCB77] hover:bg-emerald-400 text-black px-4 py-2.5 rounded-xl font-display font-black text-xs border-2 border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] hover:translate-x-[1px] hover:translate-y-[1px] hover:shadow-[1px_1px_0px_0px_rgba(0,0,0,1)] transition-all cursor-pointer flex items-center gap-2 uppercase tracking-wider"
                >
                  <Sparkles className="w-3.5 h-3.5 text-black" />
                  <span>Sort front-to-back</span>
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setSelectedSeat(null)}
                  className="bg-white hover:bg-zinc-50 text-black px-3 py-2 rounded-xl font-display font-black text-xs border-2 border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] cursor-pointer"
                  title="Clear seat selections"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </motion.button>
              </div>
            </div>

            {/* Board / Kuddus's desk */}
            <div className="space-y-2 text-center">
              <div className="bg-zinc-950 text-white font-mono font-bold py-2 px-8 rounded-xl border-2 border-black tracking-widest text-xs inline-block relative shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
                🎯 BLACKBOARD // KUDDUS SURVEILLANCE STAGE
                <span className="absolute -bottom-3 left-1/2 transform -translate-x-1/2 text-zinc-900">
                  <ArrowDown className="w-5 h-5 bg-white border-2 border-zinc-950 rounded-full p-0.5 animate-bounce" />
                </span>
              </div>
            </div>

            {/* The Seating Grid */}
            <div 
              className="grid gap-4 p-4 bg-[#FDFCF0] border-4 border-black rounded-3xl relative shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]"
              style={{
                gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))`
              }}
            >
              {grid.map((row, rIdx) => (
                row.map((cell, cIdx) => {
                  const hasStudent = cell.student !== null;
                  const isSelected = selectedSeat?.r === rIdx && selectedSeat?.c === cIdx;
                  
                  return (
                    <motion.div
                      whileHover={{ scale: 1.03 }}
                      key={`${rIdx}-${cIdx}`}
                      onClick={() => handleSeatClick(rIdx, cIdx)}
                      className={`border-4 p-3 rounded-2xl min-h-[110px] flex flex-col justify-between transition-all cursor-pointer relative ${
                        isSelected 
                          ? 'bg-pink-50 border-dashed border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]' 
                          : !hasStudent 
                            ? 'bg-zinc-100/50 border-zinc-300 border-dashed'
                            : cell.isBlocked
                              ? 'bg-red-50 border-[#FF6B6B] shadow-[4px_4px_0px_0px_rgba(255,107,107,1)] text-[#FF6B6B]'
                              : 'bg-emerald-50 border-[#6BCB77] shadow-[4px_4px_0px_0px_rgba(107,203,119,1)] text-[#6BCB77]'
                      }`}
                    >
                      {/* Seat Coordinate Label */}
                      <span className="font-mono text-[9px] text-zinc-400 block absolute top-1.5 left-2">
                        Row {rIdx + 1}, Col {cIdx + 1}
                      </span>

                      {/* Line of Sight Icon */}
                      {hasStudent && (
                        <span className="absolute top-1.5 right-2">
                          {cell.isBlocked ? (
                            <EyeOff className="w-4 h-4 text-[#FF6B6B]" title={`Sightline blocked by ${cell.blockedBy}`} />
                          ) : (
                            <Eye className="w-4 h-4 text-[#6BCB77]" title="Sightline Clear!" />
                          )}
                        </span>
                      )}

                      {/* Seat core content */}
                      <div className="pt-4 flex-1 flex flex-col justify-center">
                        {hasStudent ? (
                          <div className="space-y-1 text-center">
                            <p className="font-display font-black text-sm tracking-tight text-black leading-tight">
                              {cell.student?.name}
                            </p>
                            <p className="font-mono text-[10px] text-zinc-500 font-bold">
                              Roll: {cell.student?.roll}
                            </p>
                          </div>
                        ) : (
                          <p className="font-sans italic text-xs text-zinc-400 text-center font-medium">
                            Empty Desk
                          </p>
                        )}
                      </div>

                      {/* Height badge */}
                      {hasStudent && (
                        <div className="mt-2 flex items-center justify-between text-[10px]">
                          <span className="font-mono bg-white border-2 border-black rounded px-1 text-black font-bold">
                            {cell.student?.height} cm
                          </span>
                          {cell.isBlocked && (
                            <span className="font-sans font-bold text-[8px] text-white bg-[#FF6B6B] border border-black px-1 rounded truncate max-w-[65px]" title={`Behind ${cell.blockedBy}`}>
                              Blocked
                            </span>
                          )}
                        </div>
                      )}
                    </motion.div>
                  );
                })
              ))}
            </div>

            {/* Instruction footnote */}
            <div className="text-xs text-zinc-600 flex items-start gap-2 bg-zinc-50 p-3 rounded-xl border-2 border-black font-medium">
              <HelpCircle className="w-4 h-4 text-zinc-400 flex-shrink-0 mt-0.5" />
              <p>
                💡 <span className="font-bold text-black uppercase">Interactive Seating Matrix</span>: Click any seat, then click another seat to manually swap their positions! Swap tall and short students to inspect the real-time Line of Sight (LOS) calculation. Or click the <span className="font-bold">"Sort front-to-back"</span> button for auto-optimization.
              </p>
            </div>

          </div>
        </div>

        {/* Right Column: Student list & input ledger */}
        <div className="xl:col-span-4 space-y-6">
          
          {/* Seating efficiency summary */}
          <div className="bg-white border-4 border-black p-6 rounded-3xl shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] space-y-4">
            <h3 className="font-display font-black text-lg text-black uppercase italic">Line-Of-Sight Stats</h3>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-zinc-50 border-2 border-black p-3.5 rounded-xl text-center">
                <span className="block text-[10px] font-mono uppercase text-zinc-500 font-bold">Class Capacity</span>
                <span className="font-display font-black text-xl text-black">{studentsInGrid} / {totalGridCapacity}</span>
              </div>
              <div className="bg-zinc-50 border-2 border-black p-3.5 rounded-xl text-center">
                <span className="block text-[10px] font-mono uppercase text-zinc-500 font-bold">LOS Efficiency</span>
                <span className={`font-display font-black text-xl ${
                  efficiency >= 80 ? 'text-[#6BCB77]' : efficiency >= 50 ? 'text-pink-600' : 'text-[#FF6B6B]'
                }`}>{efficiency}%</span>
              </div>
            </div>

            <div className="text-xs space-y-1 bg-[#FDFCF0] border-2 border-black p-3 rounded-xl font-bold">
              <div className="flex justify-between">
                <span className="text-zinc-600">Sightline-Clear Students:</span>
                <span className="text-[#6BCB77] font-mono">{clearCount}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-600">Tiffin-Blocked Students:</span>
                <span className="text-[#FF6B6B] font-mono">{blockedCount}</span>
              </div>
            </div>
          </div>

          {/* Add student form */}
          <div className="bg-white border-4 border-black p-6 rounded-3xl shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] space-y-4">
            <h3 className="font-display font-black text-lg text-black flex items-center gap-2 uppercase italic">
              <Plus className="w-5 h-5 text-[#FF6B6B]" />
              <span>Enroll New Rebel</span>
            </h3>

            <form onSubmit={handleAddStudent} className="space-y-3">
              <div className="space-y-0.5">
                <label className="block text-[10px] uppercase font-bold text-zinc-500">Student Name</label>
                <input
                  type="text"
                  placeholder="e.g. Robin Hood"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  required
                  className="w-full border-2 border-black rounded-lg px-2.5 py-1.5 bg-zinc-50 text-sm focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-0.5">
                  <label className="block text-[10px] uppercase font-bold text-zinc-500">Roll Code</label>
                  <input
                    type="text"
                    placeholder="e.g. 210115"
                    value={newRoll}
                    onChange={(e) => setNewRoll(e.target.value)}
                    required
                    className="w-full border-2 border-black rounded-lg px-2.5 py-1.5 bg-zinc-50 text-sm focus:outline-none font-mono font-bold"
                  />
                </div>
                <div className="space-y-0.5">
                  <label className="block text-[10px] uppercase font-bold text-zinc-500">Height (cm)</label>
                  <input
                    type="number"
                    min={120}
                    max={210}
                    value={newHeight}
                    onChange={(e) => setNewHeight(Number(e.target.value))}
                    required
                    className="w-full border-2 border-black rounded-lg px-2.5 py-1.5 bg-zinc-50 text-sm focus:outline-none font-mono font-bold"
                  />
                </div>
              </div>

              <motion.button
                type="submit"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="w-full bg-[#FFB3C6] text-black hover:bg-pink-300 py-2.5 rounded-xl font-display font-black text-xs border-2 border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] hover:translate-x-[1px] hover:translate-y-[1px] transition-all cursor-pointer uppercase tracking-wider"
              >
                Add to Class Roll
              </motion.button>
            </form>
          </div>

          {/* Current Class Roll / Ledger list */}
          <div className="bg-white border-4 border-black p-6 rounded-3xl shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-display font-black text-lg text-black flex items-center gap-2 uppercase italic">
                <Users className="w-5 h-5 text-[#4D96FF]" />
                <span>Class Registry</span>
              </h3>
              <motion.button 
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={handleResetLedger}
                className="text-[10px] text-zinc-500 hover:text-black hover:underline font-bold uppercase tracking-wide px-2 py-1 bg-zinc-100 border border-black rounded-md shadow-[1px_1px_0px_0px_rgba(0,0,0,1)] cursor-pointer"
              >
                Reset List
              </motion.button>
            </div>

            <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
              {students.map((s) => (
                <div key={s.id} className="flex items-center justify-between p-2.5 border-2 border-black bg-zinc-50 rounded-xl text-xs">
                  <div className="flex items-center gap-2">
                    <div className="bg-zinc-200 border-2 border-black p-1 rounded-lg">
                      <User className="w-3.5 h-3.5 text-zinc-700" />
                    </div>
                    <div>
                      <p className="font-display font-black text-black leading-tight">{s.name}</p>
                      <p className="font-mono text-[9px] text-zinc-500 font-bold">Roll: {s.roll} • {s.height}cm</p>
                    </div>
                  </div>
                  <motion.button
                    whileHover={{ scale: 1.2, rotate: 90 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={() => handleRemoveStudent(s.id)}
                    className="text-red-500 hover:text-[#FF6B6B] font-black text-lg px-2 hover:bg-red-50 rounded-lg cursor-pointer"
                    title="Remove Student"
                  >
                    ×
                  </motion.button>
                </div>
              ))}
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
