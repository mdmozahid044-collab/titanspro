import React, { useState } from 'react';
import { performFactCheck, FactCheckResult } from '../utils';
import { Search, ShieldAlert, BadgeHelp, CheckCircle, HelpCircle, RefreshCw, Star, Zap } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function Mission6FactChecker() {
  const [query, setQuery] = useState('');
  const [result, setResult] = useState<FactCheckResult | null>(null);
  const [isSearching, setIsSearching] = useState(false);
  const [searchHistory, setSearchHistory] = useState<FactCheckResult[]>([]);

  const sampleClaims = [
    "University Gold Medalist",
    "PhD from Harvard",
    "Never sleeps and studies 24 hours a day",
    "Walked 20 kilometers to school",
    "Can read students' minds during exam",
    "Corrected textbook author math mistakes"
  ];

  const handleSearch = (claimText: string) => {
    if (!claimText.trim()) return;

    setIsSearching(true);
    
    // Simulate thinking network delay
    setTimeout(() => {
      const evaluation = performFactCheck(claimText);
      setResult(evaluation);
      setIsSearching(false);

      // Append to local session history if not already there
      setSearchHistory(prev => {
        const exists = prev.some(item => item.statement.toLowerCase() === evaluation.statement.toLowerCase());
        if (exists) return prev;
        return [evaluation, ...prev].slice(0, 5); // Store last 5 items
      });
    }, 600);
  };

  const getVerdictStyles = (verdict: string) => {
    switch (verdict) {
      case 'TRUE':
        return 'bg-[#6BCB77]/10 border-4 border-black text-[#2D3436] rounded-3xl shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]';
      case 'FALSE':
        return 'bg-[#FF6B6B]/10 border-4 border-black text-[#2D3436] rounded-3xl shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]';
      case 'EXAGGERATED':
        return 'bg-[#FFB3C6]/15 border-4 border-black text-[#2D3436] rounded-3xl shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]';
      case 'MYTH':
        return 'bg-[#8B5CF6]/10 border-4 border-black text-[#2D3436] rounded-3xl shadow-[8px_8px_0px_0px_rgba(139,92,246,1)]';
      default:
        return 'bg-zinc-100 border-4 border-black text-[#2D3436] rounded-3xl shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]';
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-8 py-4 text-[#2D3436]"
    >
      {/* Header Banner with Premium Purple/Yellow Contrast */}
      <motion.div 
        whileHover={{ scale: 1.01 }}
        className="bg-[#8B5CF6] text-white border-4 border-black p-6 rounded-3xl shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] relative overflow-hidden"
      >
        <div className="absolute -right-6 -bottom-6 w-24 h-24 bg-[#FFB3C6] border-4 border-black rounded-full opacity-20 pointer-events-none" />
        <h2 className="font-display font-black text-2xl md:text-3xl flex items-center gap-3 uppercase italic">
          <BadgeHelp className="w-8 h-8 text-yellow-300 animate-pulse" />
          <span>Mission 6: Kuddus Fact-Checker DB</span>
        </h2>
        <p className="font-sans text-purple-100 text-sm md:text-base mt-2 font-bold leading-relaxed">
          Verify tall legends, screen classroom propaganda, and run semantic matches against the verified student resistance archive.
        </p>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Search & Dynamic Analyzer Card */}
        <div className="lg:col-span-8 space-y-6">
          <div className="bg-white border-4 border-black p-6 rounded-3xl shadow-[8px_8px_0px_0px_rgba(139,92,246,1)] space-y-6 relative overflow-hidden">
            {/* Background Accent Grid */}
            <div className="absolute inset-0 bg-[radial-gradient(rgba(139,92,246,0.02)_1px,transparent_1px)] bg-[size:16px_16px] pointer-events-none" />

            <h3 className="font-display font-black text-lg text-black uppercase italic flex items-center gap-2 relative z-10">
              <Zap className="w-5 h-5 text-[#8B5CF6]" />
              <span>Scan Class Rumors & Claims</span>
            </h3>
            
            {/* Search Input Bar */}
            <div className="flex flex-col sm:flex-row gap-3 relative z-10">
              <div className="relative flex-1">
                <input
                  type="text"
                  placeholder="Paste or type Kuddus's claims (e.g. gold medalist, Harvard PhD...)"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSearch(query)}
                  className="w-full border-2 border-black rounded-xl pl-10 pr-4 py-3 bg-zinc-50 font-sans text-sm font-bold focus:outline-none focus:bg-white focus:border-[#8B5CF6] transition-colors shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]"
                />
                <Search className="absolute left-3 top-3.5 w-4 h-4 text-zinc-500" />
              </div>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => handleSearch(query)}
                disabled={isSearching}
                className="bg-[#8B5CF6] text-white hover:bg-purple-600 px-6 py-3 rounded-xl border-2 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:translate-x-[1px] hover:translate-y-[1px] font-display font-black text-sm cursor-pointer uppercase tracking-wide"
              >
                Analyze Claim
              </motion.button>
            </div>

            {/* Quick pre-seeded selector items */}
            <div className="space-y-2.5 relative z-10">
              <span className="block text-[10px] uppercase font-mono font-black text-[#8B5CF6] tracking-wider">Suggested Claims for Testing:</span>
              <div className="flex flex-wrap gap-2">
                {sampleClaims.map((claim, idx) => (
                  <motion.button
                    key={idx}
                    whileHover={{ scale: 1.05, y: -1 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => {
                      setQuery(claim);
                      handleSearch(claim);
                    }}
                    className="bg-[#FDFCF0] hover:bg-[#8B5CF6]/10 hover:border-[#8B5CF6] border-2 border-black text-zinc-800 rounded-xl px-3 py-1.5 font-sans text-xs font-bold transition-all cursor-pointer"
                  >
                    🔍 {claim}
                  </motion.button>
                ))}
              </div>
            </div>

            {/* Verification Loading Simulation */}
            <AnimatePresence>
              {isSearching && (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="bg-purple-50/50 border-4 border-dashed border-[#8B5CF6] py-12 rounded-2xl flex flex-col items-center justify-center gap-3 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]"
                >
                  <RefreshCw className="w-8 h-8 text-[#8B5CF6] animate-spin" />
                  <span className="font-mono text-xs text-[#8B5CF6] animate-pulse font-black uppercase tracking-wider">Retrieving database logs & verifying credentials...</span>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Evaluated Fact Card */}
            <AnimatePresence>
              {result && !isSearching && (
                <motion.div 
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -15 }}
                  transition={{ type: 'spring', stiffness: 100 }}
                  className={`p-6 border-4 border-black rounded-3xl transition-all duration-300 relative ${getVerdictStyles(result.verdict)}`}
                >
                  
                  {/* Statement Analysed Header */}
                  <div className="border-b-2 border-black pb-4 mb-4">
                    <span className="block font-mono text-[9px] uppercase tracking-wider text-zinc-500 font-bold">CLAIM SUBJECT UNDER AUDIT</span>
                    <p className="font-display font-black text-base md:text-lg italic leading-snug text-black">
                      "{result.statement}"
                    </p>
                  </div>

                  {/* Verdict Indicator Layout */}
                  <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
                    
                    {/* Verdict Badge */}
                    <div className="md:col-span-5 text-center bg-white border-4 border-black rounded-2xl p-4 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
                      <span className="block font-mono text-[9px] text-zinc-500 uppercase tracking-widest mb-1 font-black">AUDIT VERDICT</span>
                      <span className={`block font-display font-black text-xl md:text-2xl uppercase tracking-wider ${
                        result.verdict === 'TRUE' ? 'text-[#6BCB77]' :
                        result.verdict === 'FALSE' ? 'text-[#FF6B6B] animate-pulse' :
                        result.verdict === 'MYTH' ? 'text-[#8B5CF6]' : 'text-pink-600'
                      }`}>
                        {result.verdict}
                      </span>
                    </div>

                    {/* Confidence rating gauge bar with purple slider animations */}
                    <div className="md:col-span-7 space-y-2">
                      <div className="flex justify-between items-center text-xs font-bold">
                        <span className="font-mono text-zinc-600 uppercase">Verification Confidence Index:</span>
                        <span className="font-mono font-black text-black">{result.confidence}%</span>
                      </div>
                      {/* Gauge bar container */}
                      <div className="h-5 bg-white border-2 border-black rounded-lg overflow-hidden relative">
                        <motion.div 
                          initial={{ width: 0 }}
                          animate={{ width: `${result.confidence}%` }}
                          transition={{ duration: 0.6, ease: 'easeOut' }}
                          className={`h-full border-r-2 border-black ${
                            result.confidence >= 90 ? 'bg-[#6BCB77]' :
                            result.confidence >= 80 ? 'bg-[#FFB3C6]' : 'bg-[#FF6B6B]'
                          }`}
                        />
                      </div>
                    </div>

                  </div>

                  {/* Explanation text */}
                  <div className="mt-5 space-y-3 font-sans text-sm leading-relaxed">
                    <p className="font-black text-zinc-500 uppercase text-[10px] tracking-wider">Student Resistance Logs Evidence:</p>
                    <p className="text-black bg-white border-2 border-black p-4 rounded-xl shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] font-semibold italic">
                      {result.explanation}
                    </p>
                  </div>

                  {/* Archival Quote Footer */}
                  <div className="mt-4 pt-3 border-t-2 border-dashed border-black flex items-center justify-between text-[10px] font-mono font-bold text-zinc-600">
                    <span>SOURCE REFERENCE:</span>
                    <span className="font-black underline uppercase text-[#8B5CF6]">{result.ruleQuote}</span>
                  </div>

                  {result.isSimulated && (
                    <div className="mt-3 text-center">
                      <span className="inline-block bg-[#8B5CF6]/15 border-2 border-black text-black font-mono text-[9px] px-2.5 py-1 rounded-lg font-black">
                        ⚠️ Generated via Rebel Semantic Simulator
                      </span>
                    </div>
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* Right Column: Query Logs history with styled components */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-white border-4 border-black p-6 rounded-3xl shadow-[8px_8px_0px_0px_rgba(139,92,246,1)] space-y-4">
            <h3 className="font-display font-black text-lg text-black uppercase italic flex items-center gap-1.5">
              <Star className="w-5 h-5 text-yellow-400" />
              <span>Scan History Log</span>
            </h3>
            
            <div className="space-y-3 max-h-[400px] overflow-y-auto pr-1">
              {searchHistory.length === 0 ? (
                <div className="border-4 border-dashed border-zinc-100 py-12 rounded-2xl text-center text-zinc-400 font-sans text-xs font-black italic">
                  No claims analyzed yet in this session.
                </div>
              ) : (
                <div className="space-y-3">
                  {searchHistory.map((item, idx) => (
                    <motion.div 
                      initial={{ scale: 0.95, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      key={idx}
                      onClick={() => {
                        setQuery(item.statement);
                        setResult(item);
                      }}
                      className="p-3 border-2 border-black bg-zinc-50 hover:bg-[#8B5CF6]/15 rounded-xl text-xs cursor-pointer transition-all flex justify-between items-center shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] group"
                    >
                      <div className="flex-1 truncate mr-2 font-bold">
                        <p className="font-display font-black text-black truncate group-hover:text-[#8B5CF6] transition-colors">"{item.statement}"</p>
                        <p className="font-mono text-[9px] text-zinc-500">Confidence: {item.confidence}%</p>
                      </div>
                      <span className={`px-2 py-0.5 rounded font-mono text-[9px] font-black border-2 border-black uppercase ${
                        item.verdict === 'TRUE' ? 'bg-[#6BCB77]/20 text-[#6BCB77]' :
                        item.verdict === 'FALSE' ? 'bg-[#FF6B6B]/20 text-[#FF6B6B]' : 'bg-[#FFB3C6]/30 text-pink-700'
                      }`}>
                        {item.verdict}
                      </span>
                    </motion.div>
                  ))}
                </div>
              )}
            </div>
            {searchHistory.length > 0 && (
              <button
                onClick={() => setSearchHistory([])}
                className="w-full text-center font-mono text-[10px] text-zinc-500 hover:text-[#8B5CF6] hover:underline font-black uppercase tracking-wider cursor-pointer"
              >
                Clear History Logs
              </button>
            )}
          </div>
        </div>

      </div>
    </motion.div>
  );
}
