import React from 'react';
import { Home, Compass, LayoutDashboard, ShieldAlert, Wifi, Sparkles } from 'lucide-react';
import { motion } from 'motion/react';

interface NavbarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  sosCount: number;
}

export default function Navbar({ currentTab, setCurrentTab, sosCount }: NavbarProps) {
  const navItems = [
    { id: 'home', label: 'Home', decoration: 'decoration-[#FF6B6B]', hoverBg: 'hover:bg-[#FF6B6B]/15' },
    { id: 'missions', label: 'Missions', decoration: 'decoration-[#8B5CF6]', hoverBg: 'hover:bg-[#8B5CF6]/15' },
    { id: 'dashboard', label: 'Dashboard', decoration: 'decoration-[#6BCB77]', hoverBg: 'hover:bg-[#6BCB77]/15' },
  ];

  return (
    <nav className="sticky top-0 z-50 bg-[#FFB3C6] border-b-4 border-black px-4 py-3 shadow-[6px_6px_0px_0px_rgba(0,0,0,1)]">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
        {/* Brand logo with spring scale hover animation */}
        <motion.div 
          onClick={() => setCurrentTab('home')}
          whileHover={{ scale: 1.05, rotate: -1 }}
          whileTap={{ scale: 0.95 }}
          className="flex items-center gap-3 cursor-pointer group select-none"
        >
          {/* Logo container changed to a deep purple brutalist block */}
          <div className="w-10 h-10 bg-[#8B5CF6] rounded-xl flex items-center justify-center border-2 border-black transition-transform group-hover:rotate-12 shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]">
            <span className="text-white font-black text-2xl italic font-display">K</span>
          </div>
          <div>
            <span className="font-display font-black text-2xl tracking-tight text-black block leading-none uppercase italic">
              The Fall of Kodu Kuddus
            </span>
            <span className="font-mono text-[10px] text-zinc-900 block leading-none mt-1 font-black flex items-center gap-1">
              v1.15 // <span className="text-purple-800">RESISTANCE SECURE NETWORK</span>
            </span>
          </div>
        </motion.div>

        {/* Navigation Tabs */}
        <div className="flex flex-wrap items-center gap-4 font-display font-black uppercase text-sm tracking-wider">
          {navItems.map((item) => {
            const isActive = currentTab === item.id || (item.id === 'missions' && currentTab.startsWith('mission'));
            return (
              <motion.button
                key={item.id}
                id={`nav-tab-${item.id}`}
                whileHover={{ scale: 1.1, y: -2 }}
                whileTap={{ scale: 0.92 }}
                onClick={() => setCurrentTab(item.id)}
                className={`transition-all cursor-pointer px-3 py-1.5 rounded-lg border-2 border-transparent ${item.hoverBg} text-black font-black flex items-center gap-1 ${
                  isActive ? `border-black bg-white shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]` : ''
                }`}
              >
                <span>{item.label}</span>
              </motion.button>
            );
          })}

          {/* SOS Nav Tab styled with heavy brutalist purple shadow */}
          <motion.button
            id="nav-tab-sos"
            whileHover={{ scale: 1.1, y: -2, shadow: '4px 4px 0px 0px rgba(0,0,0,1)' }}
            whileTap={{ scale: 0.92 }}
            onClick={() => setCurrentTab('sos')}
            className={`font-display font-black text-sm uppercase px-3 py-1.5 rounded-xl border-2 border-black transition-all cursor-pointer flex items-center gap-1.5 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] ${
              currentTab === 'sos' || currentTab === 'mission5'
                ? 'bg-[#FF6B6B] text-white'
                : 'bg-white text-[#FF6B6B] hover:bg-[#FF6B6B] hover:text-white'
            }`}
          >
            <span>SOS</span>
            {sosCount > 0 && (
              <span className="inline-flex items-center justify-center px-1.5 py-0.5 text-xs font-mono font-bold leading-none text-white bg-black rounded-full animate-pulse">
                {sosCount}
              </span>
            )}
          </motion.button>
        </div>

        {/* Status indicator featuring purple accents */}
        <div className="hidden lg:flex items-center gap-2 bg-black text-white border-2 border-black rounded-full px-3 py-1 font-mono text-xs shadow-[3px_3px_0px_0px_rgba(139,92,246,1)]">
          <Wifi className="w-3.5 h-3.5 animate-pulse text-[#8B5CF6]" />
          <span className="font-bold">BYPASS MODE: <span className="text-[#8B5CF6]">ON</span></span>
        </div>
      </div>
    </nav>
  );
}
