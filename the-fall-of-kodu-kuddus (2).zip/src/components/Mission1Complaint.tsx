import React, { useState } from 'react';
import { Complaint, Student } from '../types';
import { INITIAL_STUDENTS } from '../constants';
import { ShieldCheck, ShieldAlert, Key, Clipboard, Send, Lock, UserCheck, Trash2 } from 'lucide-react';
import { motion } from 'motion/react';

interface Mission1ComplaintProps {
  complaints: Complaint[];
  addComplaint: (c: Complaint) => void;
  warningsCount: number;
  incrementWarnings: () => void;
  resetWarnings: () => void;
}

export default function Mission1Complaint({
  complaints,
  addComplaint,
  warningsCount,
  incrementWarnings,
  resetWarnings,
}: Mission1ComplaintProps) {
  const [rollInput, setRollInput] = useState('');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [authStudent, setAuthStudent] = useState<Student | null>(null);
  const [isHashing, setIsHashing] = useState(false);
  const [hashOutput, setHashOutput] = useState('');
  const [loginError, setLoginError] = useState('');

  // Form states
  const [category, setCategory] = useState('Homework Overload');
  const [description, setDescription] = useState('');
  const [stripMetadata, setStripMetadata] = useState(true);

  // Advanced feature placeholder: Hashing
  const simulateCredentialHash = (roll: string): Promise<string> => {
    return new Promise((resolve) => {
      let counter = 0;
      const chars = '0123456789abcdef';
      const interval = setInterval(() => {
        let fakeHash = 'SHA-256: ';
        for (let i = 0; i < 32; i++) {
          fakeHash += chars[Math.floor(Math.random() * chars.length)];
        }
        setHashOutput(fakeHash);
        counter++;
        if (counter > 8) {
          clearInterval(interval);
          // Return stable fake hash based on roll
          let finalHash = 'REBEL_SHA256_';
          for (let i = 0; i < roll.length; i++) {
            finalHash += roll.charCodeAt(i).toString(16);
          }
          finalHash += 'a9f87c2b3d';
          resolve(finalHash);
        }
      }, 100);
    });
  };

  // Advanced feature placeholder: Metadata Stripping
  const stripImageMetadataPlaceholder = (text: string) => {
    console.log("ADVANCED PRE-SUBMISSION: Metadata Stripping Engine triggered.");
    console.log("Removing EXIF headers, camera model, and GPS latitude/longitude...");
    return `[METADATA_STRIPPED: OK] ${text}`;
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    const student = INITIAL_STUDENTS.find(s => s.roll === rollInput.trim());
    
    if (!student) {
      setLoginError('INVALID ROLL CODE. Kuddus spy detector alert avoided, but entry denied.');
      return;
    }

    setIsHashing(true);
    const hash = await simulateCredentialHash(rollInput.trim());
    setIsHashing(false);
    
    setIsAuthenticated(true);
    setAuthStudent(student);
    setRollInput('');
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setAuthStudent(null);
    setHashOutput('');
  };

  const handleSubmitComplaint = (e: React.FormEvent) => {
    e.preventDefault();
    if (!description.trim()) return;

    let finalDescription = description;
    if (stripMetadata) {
      finalDescription = stripImageMetadataPlaceholder(description);
    }

    const newComplaint: Complaint = {
      id: 'c' + (complaints.length + 1),
      category,
      description: finalDescription,
      rollNumber: authStudent ? authStudent.roll : 'ANON',
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
      status: 'Received',
    };

    addComplaint(newComplaint);
    setDescription('');
    
    // Automatically trigger warning alert system periodically
    if (warningsCount < 3) {
      incrementWarnings();
    }
  };

  // Warning text lookup
  const getWarningStatusText = () => {
    if (warningsCount === 0) return 'Class record is clean (for now).';
    if (warningsCount === 1) return 'Warning 1: No smiling during textbook reading.';
    if (warningsCount === 2) return 'Warning 2: Double pop-quizzes for entire back bench.';
    return 'Warning 3: MASS SUSPENSION INITIATED!';
  };

  return (
    <div className="space-y-8 py-4 animate-fadeIn text-[#2D3436]">
      {/* Header Banner */}
      <div className="bg-[#4D96FF] text-white border-4 border-black p-6 rounded-3xl shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]">
        <h2 className="font-display font-black text-2xl md:text-3xl flex items-center gap-3 uppercase italic">
          <ShieldCheck className="w-8 h-8 text-[#FFB3C6]" />
          <span>Mission 1: Anonymous Complaint Portal</span>
        </h2>
        <p className="font-sans text-blue-50 text-sm md:text-base mt-2 font-medium">
          File complaints securely, encrypt identity hashes, and monitor the classroom suspension countdown.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Login & Complaint Form */}
        <div className="lg:col-span-7 space-y-6">
          {!isAuthenticated ? (
            /* Secure terminal login */
            <div className="bg-zinc-900 text-green-400 border-4 border-black p-6 rounded-3xl shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] font-mono space-y-4">
              <div className="flex items-center justify-between border-b border-zinc-700 pb-3">
                <span className="flex items-center gap-2 text-xs font-bold text-zinc-400">
                  <Lock className="w-4 h-4 text-[#FFB3C6]" />
                  SECURE TUNNEL TERMINAL v1.4
                </span>
                <span className="h-2 w-2 rounded-full bg-red-500 animate-ping" />
              </div>
              
              <div className="space-y-2 text-sm">
                <p>
                  [!] Welcome, Backbencher. To prevent Kuddus from reading this portal, enter your official class Roll Number.
                </p>
                <div className="bg-zinc-800 p-3 rounded-xl text-xs text-zinc-300 border border-zinc-700 space-y-1">
                  <p className="font-bold text-[#FFB3C6] uppercase">💡 Testing Roll Codes:</p>
                  <p>• Zayan: <span className="text-green-400 font-bold">210101</span> | • Nafis: <span className="text-green-400 font-bold">210102</span> | • Sanjida: <span className="text-green-400 font-bold">210103</span></p>
                  <p>• Afsana: <span className="text-green-400 font-bold">210105</span> | • Adnan: <span className="text-green-400 font-bold">210107</span></p>
                </div>
              </div>

              <form onSubmit={handleLogin} className="space-y-4 pt-2">
                <div className="space-y-2">
                  <label className="block text-xs uppercase text-zinc-400 font-bold">Roll Number Credentials</label>
                  <div className="relative">
                    <input
                      type="text"
                      placeholder="e.g. 210101"
                      value={rollInput}
                      onChange={(e) => setRollInput(e.target.value)}
                      disabled={isHashing}
                      className="w-full bg-zinc-800 border-2 border-zinc-600 rounded-xl px-3 py-2.5 text-green-400 font-mono text-sm focus:outline-none focus:border-green-500"
                    />
                    <Key className="absolute right-3 top-3 w-4 h-4 text-zinc-500" />
                  </div>
                </div>

                {isHashing && (
                  <div className="bg-zinc-850 border border-zinc-700 p-3 rounded-xl text-xs text-zinc-300">
                    <p className="animate-pulse">⏳ Encrypting ID Roll Number...</p>
                    <p className="text-[10px] text-pink-300 select-all font-mono break-all mt-1">{hashOutput}</p>
                  </div>
                )}

                {loginError && (
                  <p className="text-xs text-red-500 bg-red-950/40 p-2 rounded-xl border border-red-900">
                    {loginError}
                  </p>
                )}

                <motion.button
                  type="submit"
                  disabled={isHashing}
                  whileHover={{ scale: 1.04, y: -2 }}
                  whileTap={{ scale: 0.96 }}
                  className="w-full bg-[#6BCB77] text-black hover:bg-emerald-400 py-3 rounded-xl font-display font-black text-sm border-2 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] transition-all cursor-pointer uppercase tracking-wider"
                >
                  Encrypt & Authenticate
                </motion.button>
              </form>
            </div>
          ) : (
            /* Complaint Submission Form - Styled exactly as requested: Vibrant Blue card, white input fields */
            <div className="bg-[#4D96FF] border-4 border-black p-6 rounded-3xl shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] space-y-4 text-white">
              <div className="flex items-center justify-between border-b-2 border-white/20 pb-3">
                <div className="flex items-center gap-2 text-[#FFB3C6] font-display font-black text-sm uppercase italic">
                  <UserCheck className="w-5 h-5" />
                  <span>Agent Connected: {authStudent?.name} ({authStudent?.roll})</span>
                </div>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={handleLogout}
                  className="font-mono text-xs text-[#FFB3C6] hover:underline bg-black/30 border border-[#FFB3C6]/30 px-2 py-1 rounded-lg hover:bg-black/50"
                >
                  Sever Connection
                </motion.button>
              </div>

              <form onSubmit={handleSubmitComplaint} className="space-y-4">
                <div className="space-y-1">
                  <label className="block text-xs uppercase font-bold text-white tracking-wider">Complaint Category</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border-2 border-black text-black text-sm bg-white focus:outline-none"
                  >
                    <option>Homework Overload</option>
                    <option>Unfair Seating</option>
                    <option>Tiffin Theft</option>
                    <option>Corridor Toll</option>
                    <option>Verbal Sarcasm</option>
                    <option>Quiz Spamming</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="block text-xs uppercase font-bold text-white tracking-wider">Description / Narrative evidence</label>
                  <textarea
                    rows={4}
                    placeholder="Describe Kuddus's dictatorial offense with dates, locations, and samosa weights if applicable..."
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    required
                    className="w-full px-3 py-2 rounded-lg border-2 border-black text-black text-sm bg-white focus:outline-none"
                  />
                </div>

                {/* Advanced strip metadata checkbox placeholder */}
                <div className="flex items-center justify-between p-3 bg-black/10 border-2 border-dashed border-white/30 rounded-xl">
                  <div className="space-y-0.5">
                    <span className="block text-xs font-display font-bold text-white uppercase">Advanced: Strip Photo Metadata</span>
                    <span className="block text-[10px] text-zinc-200">Bypasses Kuddus's GPS tracing by wiping EXIF data</span>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={stripMetadata}
                      onChange={(e) => setStripMetadata(e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-white/20 rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-zinc-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#6BCB77]"></div>
                  </label>
                </div>

                <motion.button
                  type="submit"
                  whileHover={{ scale: 1.04, y: -2, shadow: '6px 6px 0px 0px rgba(255,179,198,1)' }}
                  whileTap={{ scale: 0.96 }}
                  className="w-full bg-black text-white py-3 rounded-xl font-display font-black text-sm border-2 border-black shadow-[4px_4px_0px_0px_rgba(255,179,198,1)] transition-all cursor-pointer flex items-center justify-center gap-2 uppercase tracking-wider"
                >
                  <Send className="w-4 h-4 text-[#FF6B6B]" />
                  <span>Submit Anonymous Complaint</span>
                </motion.button>
              </form>
            </div>
          )}
        </div>

        {/* Right Column: Warnings Meter & Live Logs */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* Warnings Progress Bar */}
          <div className="bg-white border-4 border-black p-6 rounded-3xl shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] space-y-4">
            <div className="flex items-center justify-between">
              <span className="font-display font-black text-lg text-black uppercase italic">Class Warnings</span>
              <span className={`font-mono text-xs font-bold border-2 border-black px-2.5 py-0.5 rounded-lg ${
                warningsCount === 3 ? 'bg-[#FF6B6B] text-white animate-bounce' : 'bg-[#FFB3C6] text-black'
              }`}>
                {warningsCount}/3 WARNINGS
              </span>
            </div>

            {/* Progress Bar Container */}
            <div className="h-6 bg-zinc-100 border-2 border-black rounded-lg overflow-hidden relative">
              <div 
                className={`h-full transition-all duration-500 border-r-2 border-black ${
                  warningsCount === 1 ? 'bg-[#FFB3C6]' :
                  warningsCount === 2 ? 'bg-orange-500' :
                  warningsCount === 3 ? 'bg-[#FF6B6B]' : 'bg-[#6BCB77]'
                }`}
                style={{ width: `${(warningsCount / 3) * 100}%` }}
              />
            </div>

            <div className="bg-zinc-50 border-2 border-black p-3 rounded-xl text-sm text-zinc-700 font-medium">
              <p className="font-bold text-black uppercase mb-1 flex items-center gap-1.5 text-xs">
                <ShieldAlert className={`w-4 h-4 ${warningsCount === 3 ? 'text-red-500 animate-spin' : 'text-zinc-600'}`} />
                Current Proclamation:
              </p>
              <p className="italic font-bold">"{getWarningStatusText()}"</p>
            </div>

            <div className="flex gap-2 font-display font-black text-xs uppercase">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={incrementWarnings}
                disabled={warningsCount >= 3}
                className="flex-1 text-center bg-[#FFB3C6] hover:bg-pink-300 border-2 border-black py-2 rounded-xl shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] active:translate-y-[1px] disabled:opacity-50 cursor-pointer"
              >
                + Push Warning
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={resetWarnings}
                className="text-center text-white bg-[#FF6B6B] hover:bg-red-500 border-2 border-black py-2 px-3 rounded-xl shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] active:translate-y-[1px] cursor-pointer"
              >
                Reset Meter
              </motion.button>
            </div>
          </div>

          {/* Active Complaint Records */}
          <div className="bg-white border-4 border-black p-6 rounded-3xl shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] space-y-4">
            <h3 className="font-display font-black text-lg text-black flex items-center gap-2 uppercase italic">
              <Clipboard className="w-5 h-5 text-[#4D96FF]" />
              <span>Rebel Complaint Vault</span>
              <span className="font-mono text-xs font-bold bg-[#FFB3C6] border-2 border-black rounded-full px-2 py-0.5 text-black">
                {complaints.length}
              </span>
            </h3>

            <div className="space-y-4 max-h-[300px] overflow-y-auto pr-1">
              {complaints.map((c) => (
                <div key={c.id} className="border-2 border-black p-3.5 rounded-xl bg-[#FDFCF0] space-y-2 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-mono font-bold text-zinc-500">ID CODE: #{c.id}</span>
                    <span className={`px-2 py-0.5 rounded-full font-mono text-[10px] border border-black font-bold uppercase ${
                      c.status === 'Received' ? 'bg-[#4D96FF]/10 text-[#4D96FF]' :
                      c.status === 'Investigating' ? 'bg-[#FFB3C6]/20 text-pink-900 animate-pulse' :
                      'bg-zinc-100 text-zinc-800'
                    }`}>
                      {c.status}
                    </span>
                  </div>

                  <p className="font-display font-black text-sm text-black">
                    [{c.category}]
                  </p>
                  
                  <p className="font-sans text-zinc-700 leading-relaxed">
                    {c.description}
                  </p>

                  <div className="flex items-center justify-between pt-2 border-t border-dashed border-zinc-200 text-[10px] text-zinc-500">
                    <span className="font-mono font-medium">Source Hash: {c.rollNumber === 'ANON' ? 'ANONYMOUS' : `SHA-${c.rollNumber}`}</span>
                    <span className="font-mono font-medium">{c.timestamp}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
