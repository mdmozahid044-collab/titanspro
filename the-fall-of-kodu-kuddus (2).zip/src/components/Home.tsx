import React from 'react';
import { DICTATORSHIP_NARRATIVE } from '../constants';
import { ArrowRight, Compass, Award, AlertTriangle, Sparkles, Star, Zap, Terminal } from 'lucide-react';
import { motion } from 'motion/react';

interface HomeProps {
  setCurrentTab: (tab: string) => void;
}

export default function Home({ setCurrentTab }: HomeProps) {
  const missions = [
    { id: 'mission1', title: 'Mission 1: Anonymous Complaint Portal', desc: 'Roll number auth & warnings system.', color: 'bg-[#4D96FF] text-white', accent: 'border-[#4D96FF]' },
    { id: 'mission2', title: 'Mission 2: Anti-Camouflage Seating', desc: 'N x M student classroom optimizer.', color: 'bg-[#FFB3C6] text-black', accent: 'border-[#FFB3C6]' },
    { id: 'mission3', title: 'Mission 3: Syllabus Negotiator', desc: 'AI interactive syllabus loophole summarizer.', color: 'bg-[#6BCB77] text-black', accent: 'border-[#6BCB77]' },
    { id: 'mission4', title: 'Mission 4: Corrupt Economy Ledger', desc: 'Tiffin theft logs & calorie calculators.', color: 'bg-orange-400 text-black', accent: 'border-orange-400' },
    { id: 'mission5', title: 'Mission 5: SOS Rescue Flare', desc: 'Real-time alert beacon & offline cache.', color: 'bg-[#FF6B6B] text-white', accent: 'border-[#FF6B6B]' },
    { id: 'mission6', title: 'Mission 6: Kuddus Fact-Checker', desc: 'Exposing academic myths and claims.', color: 'bg-[#8B5CF6] text-white', accent: 'border-[#8B5CF6]' },
  ];

  // Container motion variants
  const containerVariants = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 25, scale: 0.98 },
    show: { 
      opacity: 1, 
      y: 0, 
      scale: 1,
      transition: { 
        type: 'spring', 
        stiffness: 100,
        damping: 15
      } 
    }
  };

  const starVariants = {
    animate: {
      rotate: 360,
      transition: {
        repeat: Infinity,
        duration: 25,
        ease: 'linear'
      }
    }
  };

  return (
    <motion.div 
      variants={containerVariants}
      initial="hidden"
      animate="show"
      className="space-y-12 py-6 text-[#2D3436]"
    >
      {/* Hero Section */}
      <motion.div 
        variants={itemVariants}
        className="relative text-center bg-[#FFB3C6] border-4 border-black p-8 md:p-14 rounded-3xl shadow-[10px_10px_0px_0px_rgba(139,92,246,1)] overflow-hidden"
      >
        {/* Decorative Caution Stripes */}
        <div className="absolute top-0 left-0 right-0 h-4 bg-black flex overflow-hidden">
          {Array.from({ length: 40 }).map((_, i) => (
            <div 
              key={i} 
              className="h-full w-8 bg-[#FFB3C6] rotate-45 transform origin-top-left shrink-0"
              style={{ marginRight: '8px' }}
            />
          ))}
        </div>

        {/* Decorative Floating Purple Shapes */}
        <motion.div 
          variants={starVariants}
          animate="animate"
          className="absolute -right-8 -bottom-8 w-32 h-32 bg-[#8B5CF6] border-4 border-black rounded-[40px] opacity-25 md:opacity-40"
          style={{ clipPath: 'polygon(50% 0%, 61% 35%, 98% 35%, 68% 57%, 79% 91%, 50% 70%, 21% 91%, 32% 57%, 2% 35%, 39% 35%)' }}
        />
        <motion.div 
          animate={{ y: [0, -12, 0] }}
          transition={{ repeat: Infinity, duration: 4, ease: 'easeInOut' }}
          className="absolute left-4 top-8 w-12 h-12 bg-[#8B5CF6] border-2 border-black rounded-xl hidden md:flex items-center justify-center shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] rotate-12"
        >
          <Zap className="w-6 h-6 text-[#FFB3C6]" />
        </motion.div>

        <motion.div 
          animate={{ scale: [1, 1.1, 1] }}
          transition={{ repeat: Infinity, duration: 3, ease: 'easeInOut' }}
          className="absolute right-12 top-10 w-10 h-10 bg-[#FF6B6B] border-2 border-black rounded-full hidden md:flex items-center justify-center shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] -rotate-12"
        >
          <Star className="w-5 h-5 text-white" />
        </motion.div>

        {/* Hero Content */}
        <div className="mt-4 space-y-6 relative z-10">
          <motion.div 
            whileHover={{ scale: 1.05 }}
            className="inline-flex items-center gap-2 bg-[#8B5CF6] text-white border-4 border-black px-5 py-2 rounded-full font-mono text-xs font-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] cursor-default"
          >
            <AlertTriangle className="w-4 h-4 text-[#FFB3C6] animate-pulse" />
            <span>TOP SECRET // RESISTANCE ACCESS LEVEL XII-B</span>
          </motion.div>
          
          <h1 id="home-title" className="font-display font-black text-4xl md:text-7xl text-black tracking-tight leading-none uppercase italic">
            The Fall of <span className="text-white bg-[#8B5CF6] border-4 border-black px-3 py-1 rounded-2xl shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] inline-block my-2 rotate-[-2deg]">Kodu Kuddus</span>
          </h1>
          
          <p className="max-w-2xl mx-auto font-sans font-extrabold text-lg md:text-xl text-black leading-relaxed">
            A high-fidelity digital sandbox engineered by the backbenchers of Class XII-B to disrupt, negotiate, and systematically overthrow our academic overlord.
          </p>

          <div className="flex flex-wrap justify-center gap-4 pt-4">
            <motion.button
              whileHover={{ scale: 1.06, y: -4, shadow: '10px 10px 0px 0px rgba(139,92,246,1)' }}
              whileTap={{ scale: 0.94 }}
              onClick={() => setCurrentTab('missions')}
              className="px-8 py-4 bg-black text-[#FFB3C6] font-display font-black text-base border-4 border-black rounded-2xl shadow-[6px_6px_0px_0px_rgba(139,92,246,1)] transition-all cursor-pointer flex items-center gap-2 uppercase tracking-wide group"
            >
              <Compass className="w-5 h-5 group-hover:rotate-45 transition-transform duration-300" />
              <span>Launch Rebellion Missions</span>
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.06, y: -4, shadow: '10px 10px 0px 0px rgba(0,0,0,1)', backgroundColor: '#FFB3C6' }}
              whileTap={{ scale: 0.94 }}
              onClick={() => setCurrentTab('dashboard')}
              className="px-8 py-4 bg-white text-black font-display font-black text-base border-4 border-black rounded-2xl shadow-[6px_6px_0px_0px_rgba(139,92,246,1)] transition-all cursor-pointer uppercase tracking-wide"
            >
              View Resistance Stats
            </motion.button>
          </div>
        </div>
      </motion.div>

      {/* Advanced Decorative Purple Grid Banner */}
      <motion.div 
        variants={itemVariants}
        className="grid grid-cols-1 md:grid-cols-3 gap-6"
      >
        <div className="bg-[#8B5CF6] text-white border-4 border-black p-6 rounded-3xl shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] flex items-center gap-4">
          <div className="p-3 bg-black rounded-2xl border-2 border-white">
            <Sparkles className="w-6 h-6 text-[#FFB3C6]" />
          </div>
          <div>
            <h4 className="font-display font-black text-lg uppercase leading-none">AI RAG Compilers</h4>
            <p className="font-sans text-xs text-purple-100 mt-1 font-bold">Uncover hidden syllabus loopholes instantly.</p>
          </div>
        </div>
        <div className="bg-black text-white border-4 border-black p-6 rounded-3xl shadow-[6px_6px_0px_0px_rgba(139,92,246,1)] flex items-center gap-4">
          <div className="p-3 bg-[#8B5CF6] rounded-2xl border-2 border-black">
            <Terminal className="w-6 h-6 text-white" />
          </div>
          <div>
            <h4 className="font-display font-black text-lg uppercase leading-none text-[#FFB3C6]">Corridors Monitor</h4>
            <p className="font-sans text-xs text-zinc-400 mt-1 font-bold">Simulated online/offline WebSocket flare sync.</p>
          </div>
        </div>
        <div className="bg-white text-black border-4 border-black p-6 rounded-3xl shadow-[6px_6px_0px_0px_rgba(139,92,246,1)] flex items-center gap-4">
          <div className="p-3 bg-[#FF6B6B] rounded-2xl border-2 border-black">
            <Zap className="w-6 h-6 text-white" />
          </div>
          <div>
            <h4 className="font-display font-black text-lg uppercase leading-none">Anti-Sightline Plan</h4>
            <p className="font-sans text-xs text-zinc-600 mt-1 font-bold">Dynamic visual blockage seat coordinator.</p>
          </div>
        </div>
      </motion.div>

      {/* Narrative Section */}
      <motion.div 
        variants={itemVariants}
        className="relative bg-white border-4 border-black p-6 md:p-10 rounded-3xl shadow-[8px_8px_0px_0px_rgba(139,92,246,1)] overflow-hidden"
      >
        {/* Background Accent Lines */}
        <div className="absolute right-0 top-0 w-24 h-full bg-[#8B5CF6]/5 border-l-4 border-dashed border-black/10 hidden md:block" />
        
        <h2 className="font-display font-black text-2xl md:text-3xl text-black mb-6 border-b-4 border-black pb-3 flex items-center gap-3 uppercase italic">
          <Award className="w-7 h-7 text-[#8B5CF6]" />
          <span>{DICTATORSHIP_NARRATIVE.title}</span>
        </h2>
        <div className="space-y-4 font-sans text-zinc-800 text-base md:text-lg leading-relaxed italic font-semibold relative z-10">
          {DICTATORSHIP_NARRATIVE.paragraphs.map((p, i) => (
            <p key={i}>"{p}"</p>
          ))}
        </div>
      </motion.div>

      {/* Missions Quick Links */}
      <motion.div variants={itemVariants} className="space-y-6">
        <h2 className="font-display font-black text-2xl text-[#2D3436] flex items-center gap-3 uppercase tracking-tight italic">
          <span>Rebel Action Protocols</span>
          <span className="font-mono text-xs font-black bg-[#8B5CF6] border-2 border-black rounded-full px-3 py-1 text-white shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
            6 Active Modules
          </span>
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {missions.map((m) => (
            <motion.div 
              key={m.id}
              whileHover={{ 
                scale: 1.03, 
                y: -6, 
                shadow: '12px 12px 0px 0px rgba(139,92,246,1)' 
              }}
              whileTap={{ scale: 0.98 }}
              onClick={() => setCurrentTab(m.id)}
              className="group bg-white border-4 border-black p-6 rounded-3xl shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] transition-all cursor-pointer flex flex-col justify-between"
            >
              <div className="space-y-4">
                <div className={`inline-block border-2 border-black px-3 py-1 rounded-lg font-mono text-xs font-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] ${m.color}`}>
                  PROTOCOL CARD
                </div>
                <h3 className="font-display font-black text-xl text-black group-hover:text-[#8B5CF6] transition-colors leading-tight">
                  {m.title}
                </h3>
                <p className="font-sans text-zinc-600 text-sm leading-relaxed font-semibold">
                  {m.desc}
                </p>
              </div>
              
              <div className="flex items-center justify-end pt-4 mt-6 border-t-2 border-dashed border-zinc-200">
                <span className="font-display font-black text-xs text-black group-hover:translate-x-1 transition-transform flex items-center gap-1.5 uppercase tracking-wide">
                  Access Portal
                  <ArrowRight className="w-4 h-4 text-[#8B5CF6]" />
                </span>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </motion.div>
  );
}
