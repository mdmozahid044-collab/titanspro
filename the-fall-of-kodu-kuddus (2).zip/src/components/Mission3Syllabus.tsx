import React, { useState } from 'react';
import { BookOpen, FileText, Sparkles, Download, HelpCircle, Send, MessageSquare } from 'lucide-react';
import { motion } from 'motion/react';

interface StudyTask {
  day: string;
  topic: string;
  rebelStrategy: string;
  priority: 'CRITICAL' | 'FLUFF' | 'SKIP';
}

export default function Mission3Syllabus() {
  const [syllabusInput, setSyllabusInput] = useState(
    "Mathematics XII:\n" +
    "1. Integral Calculus (Definite Integrals & Areas)\n" +
    "2. Differential Equations (Applications to growth models)\n" +
    "3. Three Dimensional Geometry (Lines and planes in space)\n" +
    "4. Probability Distributions (Binomial & Poisson)"
  );
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisLogs, setAnalysisLogs] = useState<string[]>([]);
  const [negotiatedResult, setNegotiatedResult] = useState<string[] | null>(null);
  const [studyPlan, setStudyPlan] = useState<StudyTask[] | null>(null);

  // RAG States
  const [ragQuery, setRagQuery] = useState('');
  const [ragChatHistory, setRagChatHistory] = useState<Array<{ sender: 'user' | 'bot'; text: string }>>([
    { sender: 'bot', text: 'Syllabus Loophole Scanner is online. Paste your syllabus and ask me anything about exam delay strategies, or which chapters can be bribe-skipped!' }
  ]);

  // AI Simulation Engine
  const handleNegotiate = () => {
    if (!syllabusInput.trim()) return;

    setIsAnalyzing(true);
    setAnalysisLogs([]);
    setNegotiatedResult(null);

    const logs = [
      "Initializing anti-syllabus compiler...",
      "Mapping academic load vectors...",
      "Interrogating past exam questions from Kuddus\'s wastebasket...",
      "Simulating Samosa-to-grade bribe coefficients...",
      "Loophole optimization completed successfully!"
    ];

    // Trigger step-by-step logs simulation
    let logIndex = 0;
    const interval = setInterval(() => {
      if (logIndex < logs.length) {
        setAnalysisLogs(prev => [...prev, logs[logIndex]]);
        logIndex++;
      } else {
        clearInterval(interval);
        generateNegotiatedSyllabus();
        setIsAnalyzing(false);
      }
    }, 400);
  };

  const generateNegotiatedSyllabus = () => {
    // Basic parser of pasted lines
    const lines = syllabusInput.split('\n').filter(l => l.trim().length > 3);
    const results: string[] = [];
    const plan: StudyTask[] = [];

    // Rebel critique lines generator
    const funnyCritiques = [
      "Skip entirely. Kuddus only asks this when he is in an incredibly foul mood, which is unpredictable. Better spend this time perfecting your poker face.",
      "Cram Zone. Kuddus loves this chapter because he can invent complex symbols. Study for 40 minutes at 2 AM using backbencher cheat sheets.",
      "Pure academic fluff. This was written to inflate the textbook size. Suggest drawing a cartoon of Kuddus in the page margin instead of studying.",
      "Critical Red Alert. Kuddus was spotted smiling while holding this chapter file in the library. He will definitely put a 15-mark trick question about this. Study immediately!",
      "Procrastination safe-haven. This topic has 0% real-world utility but 100% chance of causing severe exam fatigue. Read the summaries only."
    ];

    lines.forEach((line, index) => {
      const cleaned = line.replace(/^\d+\.?\s*/, '').trim();
      const critique = funnyCritiques[index % funnyCritiques.length];
      results.push(`🚨 ${cleaned} → Rebel Recommendation: ${critique}`);

      // Map to structured study plan
      const priorities: Array<'CRITICAL' | 'FLUFF' | 'SKIP'> = ['CRITICAL', 'SKIP', 'FLUFF'];
      plan.push({
        day: `Rebel Day ${index + 1}`,
        topic: cleaned,
        rebelStrategy: critique,
        priority: priorities[index % priorities.length]
      });
    });

    // In case syllabus is too short, pad with funny ones
    if (results.length === 0) {
      results.push("Syllabus parsed: Empty. Rebel Verdict: Freedom! Go buy samosas.");
      plan.push({
        day: "Rebel Day 1",
        topic: "Buying Samosas",
        rebelStrategy: "Procure warm samosas to establish school corridor supremacy.",
        priority: 'SKIP'
      });
    }

    setNegotiatedResult(results);
    setStudyPlan(plan);
  };

  // RAG simulation based on user pasted syllabus
  const handleRagSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!ragQuery.trim()) return;

    const userMsg = ragQuery;
    setRagChatHistory(prev => [...prev, { sender: 'user', text: userMsg }]);
    setRagQuery('');

    // Simulate RAG scanning Pasted Syllabus
    setTimeout(() => {
      const qLower = userMsg.toLowerCase();
      const lines = syllabusInput.split('\n').filter(l => l.trim().length > 3);
      
      // Try to find a chapter name mentioned in pasted syllabus
      let matchedChapter = "";
      for (const line of lines) {
        const cleaned = line.replace(/^\d+\.?\s*/, '').trim();
        if (cleaned && qLower.includes(cleaned.toLowerCase().split(' ')[0])) {
          matchedChapter = cleaned;
          break;
        }
      }

      let answer = "";
      if (qLower.includes('delay') || qLower.includes('postpone') || qLower.includes('quiz')) {
        answer = "⚠️ LOOPHOLE ALERT: Section 4 of Kuddus's handbook says a quiz cannot be held if the classroom's humidity is above 90% or if the ceiling fan makes 'threatening structural noises'. We suggest placing a damp cloth on the thermostat and loosening the fan shroud!";
      } else if (qLower.includes('cheat') || qLower.includes('pass') || qLower.includes('study')) {
        answer = "🤫 BACKBENCHER STRATEGY: Do not attempt to read the entire text. Instead, read the summary page and memorize exactly 3 phrases: 'According to leading theorists...', 'In standard conditions...', and 'The remaining integration is trivial'. Kuddus rarely grades beyond the second line.";
      } else if (matchedChapter) {
        answer = `🔍 SCANNING FOR LOOPHOLES IN "${matchedChapter}": Found a massive formatting error in Section 3 of this chapter. The textbook lists a formula with a missing division sign. If Kuddus asks this in the exam, the entire class can claim the question is 'mathematically illegal' and demand 10 bonus marks!`;
      } else {
        answer = "🤖 SYSTEM ADVICE: Pasted syllabus scan does not contain direct answers for this question, but classroom legends suggest that mentioning 'The thermodynamic efficiency of Kodu plants' during your answer sheet introduction confuses Kuddus into giving an automatic B+.";
      }

      setRagChatHistory(prev => [...prev, { sender: 'bot', text: answer }]);
    }, 600);
  };

  // Export study plan to JSON
  const handleExportJSON = () => {
    if (!studyPlan) return;

    const exportData = {
      title: "Rebel Academy Action Plan - Anti Kuddus Syllabus Bypass",
      generatedDate: "2026-07-12",
      class: "XII-B Backbenchers Coalition",
      plan: studyPlan,
      survivalTips: [
        "Never make direct eye contact with Kuddus while chewing gum.",
        "Keep a backup pencil box containing exact change for corridor washroom tolls."
      ]
    };

    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(exportData, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", "Anti_Kuddus_Study_Survival_Plan.json");
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="space-y-8 py-4 animate-fadeIn text-[#2D3436]">
      {/* Header Banner */}
      <div className="bg-[#6BCB77] text-black border-4 border-black p-6 rounded-3xl shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]">
        <h2 className="font-display font-black text-2xl md:text-3xl flex items-center gap-3 uppercase italic">
          <BookOpen className="w-8 h-8 text-black" />
          <span>Mission 3: Syllabus Negotiator & RAG Engine</span>
        </h2>
        <p className="font-sans text-black/80 text-sm md:text-base mt-2 font-medium">
          Paste Kuddus's heavy syllabus, run the anti-overload compiler to get strategic skip tips, ask our RAG loophole bot questions, and export your schedule.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Syllabus Input & Negotiated Output */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-white border-4 border-black p-6 rounded-3xl shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] space-y-4">
            <h3 className="font-display font-black text-lg text-black flex items-center gap-2 uppercase italic">
              <FileText className="w-5 h-5 text-[#6BCB77]" />
              <span>Input Syllabus Document</span>
            </h3>

            <div className="space-y-2">
              <textarea
                rows={6}
                value={syllabusInput}
                onChange={(e) => setSyllabusInput(e.target.value)}
                placeholder="Paste the boring textbook chapters list here..."
                className="w-full border-2 border-black rounded-xl p-3 bg-zinc-50 font-sans text-sm focus:outline-none"
              />
              <p className="font-mono text-[10px] text-zinc-500 font-bold">
                Type or paste list with numbers or bullet points for the AI compiler.
              </p>
            </div>

            <motion.button
              onClick={handleNegotiate}
              disabled={isAnalyzing || !syllabusInput.trim()}
              whileHover={{ scale: 1.04, y: -2 }}
              whileTap={{ scale: 0.96 }}
              className="w-full bg-[#6BCB77] text-black hover:bg-emerald-400 py-3 rounded-xl font-display font-black text-sm border-2 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] transition-all cursor-pointer flex items-center justify-center gap-2 uppercase tracking-wider"
            >
              <Sparkles className="w-4 h-4 text-black animate-spin" />
              <span>{isAnalyzing ? 'Negotiating Loopholes...' : 'Compile Syllabus & Build Loopholes'}</span>
            </motion.button>

            {isAnalyzing && (
              <div className="bg-zinc-950 border-2 border-black p-4 rounded-xl font-mono text-xs text-[#6BCB77] space-y-1.5 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
                <p className="text-[#FFB3C6] border-b border-zinc-700 pb-1 font-bold">AI COMPILE STATUS ENGINE:</p>
                {analysisLogs.map((log, index) => (
                  <p key={index} className="animate-fadeIn">⚡ {log}</p>
                ))}
              </div>
            )}

            {/* AI Summarized Recommendations */}
            {negotiatedResult && (
              <div className="space-y-4 pt-4 border-t-2 border-black border-dashed animate-fadeIn">
                <div className="flex items-center justify-between">
                  <h4 className="font-display font-black text-sm text-black uppercase italic">
                    Compiled Rebel Bulletins
                  </h4>
                  <span className="font-mono text-[9px] bg-[#6BCB77]/20 border-2 border-[#6BCB77] rounded px-2 text-[#6BCB77] font-bold uppercase">
                    AI generated ok
                  </span>
                </div>

                <div className="space-y-3">
                  {negotiatedResult.map((res, i) => (
                    <div key={i} className="bg-[#6BCB77]/10 border-2 border-black p-3 rounded-xl font-sans text-xs text-zinc-900 leading-relaxed font-semibold">
                      {res}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Loophole Chat Bot & Export Panel */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* Syllabus RAG chat simulation */}
          <div className="bg-white border-4 border-black p-6 rounded-3xl shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] space-y-4">
            <h3 className="font-display font-black text-lg text-black flex items-center gap-2 uppercase italic">
              <MessageSquare className="w-5 h-5 text-[#FF6B6B]" />
              <span>Syllabus Loophole RAG Bot</span>
            </h3>

            {/* Simulated Chat Interface */}
            <div className="bg-[#FDFCF0] border-2 border-black rounded-2xl p-3 h-[250px] overflow-y-auto space-y-3 flex flex-col">
              {ragChatHistory.map((msg, i) => (
                <div 
                  key={i} 
                  className={`max-w-[85%] rounded-2xl p-2.5 text-xs font-sans leading-relaxed border-2 border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] ${
                    msg.sender === 'user' 
                      ? 'bg-zinc-950 text-white self-end rounded-br-none' 
                      : 'bg-[#FFB3C6] text-black self-start rounded-bl-none'
                  }`}
                >
                  <p className="font-mono text-[8px] uppercase text-zinc-400 mb-0.5 font-bold">
                    {msg.sender === 'user' ? 'Rebel Backbencher' : 'RAG Loophole Assistant'}
                  </p>
                  <p className="font-medium">{msg.text}</p>
                </div>
              ))}
            </div>

            <form onSubmit={handleRagSearch} className="flex gap-2">
              <input
                type="text"
                placeholder="Ask: How to delay exams? or chapter..."
                value={ragQuery}
                onChange={(e) => setRagQuery(e.target.value)}
                className="flex-1 border-2 border-black rounded-xl px-3 py-2 bg-zinc-50 text-xs focus:outline-none"
              />
              <motion.button
                type="submit"
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                className="bg-black text-[#FFB3C6] hover:bg-[#FFB3C6] hover:text-black px-3.5 py-2 rounded-xl border-2 border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] cursor-pointer transition-colors"
              >
                <Send className="w-4 h-4" />
              </motion.button>
            </form>
          </div>

          {/* Export study planner calendar to JSON */}
          {studyPlan && (
            <div className="bg-white border-4 border-black p-6 rounded-3xl shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] space-y-4 animate-fadeIn">
              <h3 className="font-display font-black text-lg text-black uppercase italic">Action Study Planner</h3>
              
              <div className="space-y-2 max-h-[160px] overflow-y-auto">
                {studyPlan.map((p, i) => (
                  <div key={i} className="flex items-center justify-between p-2 border-2 border-black rounded-lg text-[11px] bg-zinc-50 font-semibold">
                    <div>
                      <span className="font-mono text-zinc-500 mr-2">{p.day}:</span>
                      <span className="font-display font-black text-black">{p.topic}</span>
                    </div>
                    <span className={`font-mono text-[9px] px-1.5 py-0.5 rounded border border-black font-bold ${
                      p.priority === 'CRITICAL' ? 'bg-[#FF6B6B]/20 text-red-800' :
                      p.priority === 'SKIP' ? 'bg-[#6BCB77]/20 text-green-800' : 'bg-zinc-200 text-zinc-700'
                    }`}>
                      {p.priority}
                    </span>
                  </div>
                ))}
              </div>

              <motion.button
                onClick={handleExportJSON}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="w-full bg-[#FFB3C6] hover:bg-pink-300 text-black py-2.5 rounded-xl font-display font-black text-xs border-2 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:translate-x-[1px] hover:translate-y-[1px] transition-all cursor-pointer flex items-center justify-center gap-1.5 uppercase tracking-wider"
              >
                <Download className="w-4 h-4 text-black" />
                <span>Export Rebel Plan to JSON</span>
              </motion.button>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}
