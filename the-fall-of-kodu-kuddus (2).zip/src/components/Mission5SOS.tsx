import React, { useState, useEffect } from 'react';
import { SOSAlert } from '../types';
import { ShieldAlert, AlertTriangle, Send, Wifi, WifiOff, Trash2, CheckCircle2, CloudLightning } from 'lucide-react';
import { motion } from 'motion/react';

interface Mission5SOSProps {
  alerts: SOSAlert[];
  addAlert: (a: SOSAlert) => void;
  resolveAlert: (id: string) => void;
  clearAlerts: () => void;
}

export default function Mission5SOS({ alerts, addAlert, resolveAlert, clearAlerts }: Mission5SOSProps) {
  const [location, setLocation] = useState('Classroom');
  const [message, setMessage] = useState('');
  const [reporter, setReporter] = useState('Agent Backbencher');
  
  // Advanced simulation states
  const [isOffline, setIsOffline] = useState(false);
  const [offlineCache, setOfflineCache] = useState<SOSAlert[]>([]);
  const [wsLogs, setWsLogs] = useState<string[]>([]);
  const [showBlastAnimation, setShowBlastAnimation] = useState(false);

  // Sync offline cache when coming back online
  useEffect(() => {
    if (!isOffline && offlineCache.length > 0) {
      appendWsLog("🌐 Internet connection restored. Triggering offline sync cache...");
      
      // Sync each cached alert
      offlineCache.forEach((cachedAlert, index) => {
        setTimeout(() => {
          const syncedAlert = { ...cachedAlert, isSynced: true };
          addAlert(syncedAlert);
          appendWsLog(`[WS-SYNC] Successfully broadcast offline cache item #${cachedAlert.id} to Rebel Network.`);
        }, (index + 1) * 500);
      });

      setOfflineCache([]);
    }
  }, [isOffline, offlineCache]);

  const appendWsLog = (text: string) => {
    setWsLogs(prev => [...prev.slice(-6), text]); // Keep last 7 logs
  };

  const triggerSOSFlare = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;

    setShowBlastAnimation(true);
    setTimeout(() => setShowBlastAnimation(false), 2000);

    const newAlert: SOSAlert = {
      id: 'sos_' + Math.round(1000 + Math.random() * 9000),
      location,
      message: message.trim(),
      timestamp: new Date().toLocaleTimeString(),
      reporter: reporter.trim(),
      status: 'ACTIVE',
      isSynced: !isOffline,
    };

    if (isOffline) {
      setOfflineCache(prev => [...prev, newAlert]);
      appendWsLog(`[CACHE] Local storage write. Alert #${newAlert.id} cached offline.`);
    } else {
      addAlert(newAlert);
      appendWsLog(`[WS-SEND] Broadcast packet: SOS Location: ${location} | msg: "${message.substring(0, 15)}..."`);
      appendWsLog(`[WS-ACK] Mirror broadcast echoed to 12 active peer nodes.`);
    }

    setMessage('');
  };

  const handleResolveAlert = (id: string) => {
    resolveAlert(id);
    appendWsLog(`[SYSTEM] Alert #${id} marked RESOLVED. Bribe/Distraction completed.`);
  };

  return (
    <div className="space-y-8 py-4 animate-fadeIn text-[#2D3436]">
      {/* Header Banner */}
      <div className="bg-[#FF6B6B] text-black border-4 border-black p-6 rounded-3xl shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]">
        <h2 className="font-display font-black text-2xl md:text-3xl flex items-center gap-3 uppercase italic">
          <ShieldAlert className="w-8 h-8 text-black animate-pulse" />
          <span>Mission 5: SOS Rescue Flare Beacon</span>
        </h2>
        <p className="font-sans text-black/80 text-sm md:text-base mt-2 font-medium">
          Fire emergency flares to alert Captains of sudden inspections or pop-quiz drafts. Simulate WebSocket broadcasts and offline sync queues.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Big SOS button & flare settings */}
        <div className="lg:col-span-6 space-y-6">
          <div className="bg-white border-4 border-black p-6 rounded-3xl shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] space-y-6">
            
            {/* Sync connection switch */}
            <div className="flex items-center justify-between p-3.5 bg-[#FDFCF0] border-2 border-black rounded-xl shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
              <div>
                <span className="block text-sm font-display font-black text-black uppercase">Network Sync State</span>
                <span className="block text-[10px] text-zinc-500 font-mono font-bold">
                  {isOffline ? 'OFFLINE CACHE RUNNING' : 'PEER CONNECTION SECURED'}
                </span>
              </div>
              <motion.button
                onClick={() => {
                  setIsOffline(!isOffline);
                  appendWsLog(isOffline ? "💡 Connection online. Syncing local queue..." : "🚫 Simulating offline cache mode.");
                }}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className={`px-3 py-1.5 rounded-lg border-2 border-black font-display font-black text-xs shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] cursor-pointer flex items-center gap-1.5 uppercase ${
                  isOffline ? 'bg-[#FF6B6B]/20 text-[#FF6B6B]' : 'bg-[#6BCB77]/20 text-[#6BCB77]'
                }`}
              >
                {isOffline ? (
                  <>
                    <WifiOff className="w-3.5 h-3.5 text-[#FF6B6B]" />
                    <span>Go Online</span>
                  </>
                ) : (
                  <>
                    <Wifi className="w-3.5 h-3.5 text-[#6BCB77]" />
                    <span>Go Offline</span>
                  </>
                )}
              </motion.button>
            </div>

            {/* Launch Fire Flare Form */}
            <form onSubmit={triggerSOSFlare} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="block text-[10px] uppercase font-bold text-zinc-500">SOS Location</label>
                  <select
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    className="w-full border-2 border-black rounded-lg px-3 py-2 bg-zinc-50 text-sm focus:outline-none focus:bg-white font-display font-black"
                  >
                    <option>Library</option>
                    <option>Playground</option>
                    <option>Corridor</option>
                    <option>Classroom</option>
                    <option>Canteen</option>
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="block text-[10px] uppercase font-bold text-zinc-500">Agent Alias</label>
                  <input
                    type="text"
                    value={reporter}
                    onChange={(e) => setReporter(e.target.value)}
                    required
                    className="w-full border-2 border-black rounded-lg px-3 py-2 bg-zinc-50 text-sm focus:outline-none font-bold"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="block text-[10px] uppercase font-bold text-zinc-500">Intruding Emergency Description</label>
                <textarea
                  rows={2}
                  placeholder="e.g. Kuddus is walking toward Classroom with red grading pen!"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  required
                  className="w-full border-2 border-black rounded-lg p-3 bg-zinc-50 text-sm focus:outline-none"
                />
              </div>

              {/* The BIG RED SOS button */}
              <div className="flex flex-col items-center justify-center pt-2 relative">
                <motion.button
                  type="submit"
                  whileHover={{ scale: 1.15, rotate: 2, shadow: '8px 8px 0px 0px rgba(0,0,0,1)' }}
                  whileTap={{ scale: 0.9 }}
                  className={`w-32 h-32 rounded-full border-4 border-black font-display font-black text-2xl text-black shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] transition-all cursor-pointer outline-none relative overflow-hidden flex flex-col items-center justify-center gap-1 ${
                    showBlastAnimation ? 'bg-[#FF6B6B] animate-pulse' : 'bg-[#FF6B6B]'
                  }`}
                >
                  <CloudLightning className="w-7 h-7 text-black animate-bounce" />
                  <span>SOS</span>
                  <span className="text-[10px] uppercase font-mono tracking-widest text-black/75">Launch Flare</span>
                </motion.button>
                {showBlastAnimation && (
                  <div className="absolute inset-0 bg-red-100/30 rounded-2xl flex items-center justify-center font-display font-black text-red-600 text-lg uppercase tracking-widest animate-pulse pointer-events-none">
                    💥 FLARE LAUNCHED!
                  </div>
                )}
              </div>
            </form>

            {/* Offline queue indicators */}
            {offlineCache.length > 0 && (
              <div className="bg-[#FF6B6B]/10 border-2 border-black p-3.5 rounded-xl font-sans text-xs text-red-950 space-y-1 animate-pulse font-medium">
                <p className="font-bold flex items-center gap-1.5 uppercase text-red-950">
                  <AlertTriangle className="w-4 h-4 text-[#FF6B6B]" />
                  Offline Sync Queue: {offlineCache.length} Alert(s) cached
                </p>
                <p>These alarms are stored locally. They will automatically sync to the Captains' monitors when Online Mode is restored.</p>
              </div>
            )}

          </div>
        </div>

        {/* Right Column: WebSocket Monitor logs & Captains Alerts list */}
        <div className="lg:col-span-6 space-y-6">
          
          {/* Captains monitoring console */}
          <div className="bg-white border-4 border-black p-6 rounded-3xl shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-display font-black text-lg text-black flex items-center gap-2 uppercase italic">
                <ShieldAlert className="w-5 h-5 text-[#FF6B6B]" />
                <span>Captains Monitor Panel</span>
              </h3>
              <button
                onClick={clearAlerts}
                className="text-[10px] text-zinc-500 hover:text-black hover:underline font-bold uppercase tracking-wide"
              >
                Clear Archives
              </button>
            </div>

            <div className="space-y-3 max-h-[280px] overflow-y-auto pr-1">
              {alerts.length === 0 ? (
                <div className="border-2 border-dashed border-zinc-200 py-10 rounded-xl text-center text-zinc-400 font-sans text-xs italic">
                  No active emergencies reported. The corridors are clear.
                </div>
              ) : (
                alerts.map((a) => (
                  <div 
                    key={a.id} 
                    className={`border-4 p-4 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-4 transition-all ${
                      a.status === 'ACTIVE' 
                        ? 'bg-[#FF6B6B]/10 border-[#FF6B6B] shadow-[4px_4px_0px_0px_rgba(255,107,107,1)]' 
                        : 'bg-zinc-50 border-zinc-300 text-zinc-500'
                    }`}
                  >
                    <div className="space-y-1.5 flex-1">
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span className="font-display font-black text-xs text-black bg-[#FFB3C6] border-2 border-black px-2 rounded-lg">
                          📍 {a.location}
                        </span>
                        <span className="font-mono text-[9px] text-zinc-500 font-bold">#{a.id} • {a.timestamp}</span>
                        {!a.isSynced && (
                          <span className="bg-[#FF6B6B]/20 text-[#FF6B6B] text-[8px] font-mono font-black px-1.5 py-0.5 rounded border border-black uppercase">OFFLINE</span>
                        )}
                      </div>

                      <p className="font-sans text-sm font-bold leading-relaxed text-black">
                        "{a.message}"
                      </p>

                      <p className="font-mono text-[10px] text-zinc-500 font-bold">
                        Reporter: <span className="font-black text-black">{a.reporter}</span>
                      </p>
                    </div>

                    {a.status === 'ACTIVE' && (
                      <button
                        onClick={() => handleResolveAlert(a.id)}
                        className="bg-[#6BCB77] hover:bg-emerald-400 text-black p-2 border-2 border-black rounded-lg shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] hover:translate-x-[1px] hover:translate-y-[1px] cursor-pointer"
                        title="Mark alert resolved"
                      >
                        <CheckCircle2 className="w-5 h-5 text-black" />
                      </button>
                    )}
                  </div>
                ))
              )}
            </div>
          </div>

          {/* WebSocket stream logs */}
          <div className="bg-zinc-950 text-green-400 font-mono text-[11px] p-5 border-4 border-black rounded-3xl shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] space-y-3.5">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-2">
              <span className="flex items-center gap-1.5 text-xs text-zinc-400 font-bold">
                <Wifi className="w-3.5 h-3.5 text-[#6BCB77] animate-pulse" />
                REBEL_DAEMON_BROADCAST_LOG
              </span>
            </div>

            <div className="space-y-1.5 h-[120px] overflow-y-auto">
              {wsLogs.length === 0 ? (
                <p className="text-zinc-600 italic">No connection log packets captured yet. Fire a flare above to initialize broadcast stream.</p>
              ) : (
                wsLogs.map((log, index) => (
                  <p key={index} className="leading-relaxed text-[#6BCB77]">⚡ {log}</p>
                ))
              )}
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
